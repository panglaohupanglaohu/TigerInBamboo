// =====================================================================
//  弹唱老人互动：靠近按 E 播放 / 停止 BGM（Balmorhea-Remembrance.mp3 · 0–5:49）
//  老人现坐在圣城旧港码头起重机旁；距离用世界坐标（可能挂在码头子树下）
// =====================================================================
import * as THREE from "three";
import { toggleMusicBox, isMusicBoxPlaying, isMuted } from "../audio/sfx.js";
import { showToast } from "../ui/hud.js";

export const ELDER_MUSIC_RANGE = 4.5;

/**
 * @param {object} deps
 * @param {object} deps.player
 * @param {import("three").Object3D|null} deps.elder
 * @param {HTMLElement|null} deps.elHint
 * @param {() => boolean} deps.isGameStarted
 * @param {() => boolean} [deps.shouldYieldKeyE] 主线暗号交互需要 E 时让位
 */
export function createElderMusicInteraction({
  player, elder: elderInit, elHint, isGameStarted,
  /** 送信人是否正在驾驶载具——是则不许隔着船舷听八音盒 */
  isBusyRiding = () => false,
  // 主线对暗号的 E 优先（狐狸就在八音盒旁）：虎/狐章节靠近目标时八音盒让位
  shouldYieldKeyE = () => false,
}) {
  let elder = elderInit || null;
  let notePulse = 0;
  let keys = elder?.userData?.musicKeys || null;
  let baseKeysY = keys?.position.y ?? 0;
  const _elderWorld = new THREE.Vector3();

  function nearElder() {
    // 老人可能挂在码头等子节点下，须用世界坐标判断近身
    if (!elder) return false;
    if (isBusyRiding()) return false; // 坐在载具上不算近身（见 main.js 的同名闸）
    elder.getWorldPosition(_elderWorld);
    return player.position.distanceTo(_elderWorld) <= ELDER_MUSIC_RANGE;
  }

  function refreshHint() {
    if (!elHint) return;
    // 主线暗号优先时隐藏八音盒提示（狐狸就在八音盒旁，避免 E 含义混淆）
    const show = !!isGameStarted?.() && nearElder() && !shouldYieldKeyE?.();
    elHint.classList.toggle("show", show);
    if (show) {
      elHint.innerHTML = isMusicBoxPlaying()
        ? "[<kbd>E</kbd>] 停止八音盒"
        : "[<kbd>E</kbd>] 聆听八音盒";
    }
  }

  function onKeyDown(event) {
    if (event.code !== "KeyE" || event.repeat || !isGameStarted?.()) return;
    // 主线对暗号（虎/狐章节靠近按 E）优先，八音盒让位
    if (shouldYieldKeyE?.()) return;
    if (!nearElder()) return;
    // 捕获阶段接管老人附近的 E，避免与送信 NPC / 阿狸同时触发。
    event.preventDefault();
    event.stopImmediatePropagation();

    if (isMuted()) {
      showToast("音效已关闭 · 按 M 开启后再听八音盒", 2.2);
      refreshHint();
      return;
    }

    const wasPlaying = isMusicBoxPlaying();
    const started = toggleMusicBox({
      onNote: () => { notePulse = 1; },
      onEnded: refreshHint,
    });
    if (started) {
      showToast("老人轻轻转动发条，八音盒响了起来……", 3);
    } else if (wasPlaying) {
      showToast("八音盒安静下来", 1.8);
    } else {
      showToast("八音盒此刻无法响起（可能被其他音乐占用）", 2.2);
    }
    notePulse = started ? 1 : 0;
    refreshHint();
  }

  window.addEventListener("keydown", onKeyDown, { capture: true });

  function update(dt, t) {
    // 热更新 keys（老人晚挂载时）
    if (!keys && elder?.userData?.musicKeys) {
      keys = elder.userData.musicKeys;
      baseKeysY = keys.position.y ?? 0;
    }
    refreshHint();
    if (!keys) return;
    notePulse = Math.max(0, notePulse - dt * 5.5);
    const playing = isMusicBoxPlaying();
    const sway = playing ? Math.sin(t * 9) * 0.005 : 0;
    keys.position.y = baseKeysY + sway + notePulse * 0.035;
    keys.rotation.z = playing ? Math.sin(t * 5.5) * 0.018 : 0;
  }

  return {
    update,
    isNear: nearElder,
    /** 老人迁到码头后可热绑定 */
    setElder(next) {
      elder = next || null;
      keys = elder?.userData?.musicKeys || null;
      baseKeysY = keys?.position.y ?? 0;
    },
    dispose() {
      window.removeEventListener("keydown", onKeyDown, { capture: true });
      if (elHint) elHint.classList.remove("show");
    },
  };
}
