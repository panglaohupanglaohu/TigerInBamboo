import { installSwampWarshipRowing } from './swampWarshipRowing.js';
import {installFlowerBoatPaddles, installFlowerBoyActivities} from './swampFlowerActivities.js';
import {applySwampInternalGlow} from './swampInternalGlow.js';
import {applySwampV2Art} from './swampV2Art.js';
import {faunaTube} from './swampFaunaGeometry.js';
import {createSwampAlgaeClumps} from './swampAlgaeClumps.js';
// =====================================================================
//  莫比斯原初湖沼 · createMoebiusSwampZone()  —— 月夜重构版（对照参考截屏）
//
//  概念：湖沼被四周苍天大树环抱，树冠在坑口上方交织成顶棚，
//  水面不见阳光，整片湖沼有如月夜 —— 仅借萤火虫与发光花蕊两种光。
//  因此全沼使用不受光平涂材质（不接收全局昼夜光照），以深蓝绿月夜
//  色板还原参考图的扁平插画感；鲸豚/花蕊为画面亮色主体。
//
//  Y 轴绝对坐标分层（局部 Group 内锁死）：
//    Y = 40.0  正常球体地面高度（玩家行走的草地 / 坑口缘）
//    Y = 25.0  地下半透明湖沼水面（比地表低整整 15 个单位）
//    Y = 10.0  坑洞最深处湖底沙地（总水深 15：从 Y=10 到 Y=25）
//    Y = 50~60 树冠顶棚（苍天大树枝冠交织遮天）
//
//  核心资产：
//    - 自发光半透明青绿水面 + 深蓝水下剖面（月夜不见阳光）
//    - 珍珠瓷感异星白鲸 / 焦黑土著人偶 / 内凹荷叶小舟（载粉色发光花蕊）
//    - 树冠顶棚 + 巨叶垂吊 / 萤火虫群 / 发光花蕊 / 微弱月光柱
//    - 全件 addOutline() 墨线描边，莫比斯插画感
// =====================================================================
import * as THREE from "three";
import { addOutline, INK_COLOR } from "../assets/toon.js";
import { createSwampGroundSampler } from "./swampGround.js";
import { createMoebiusTiger } from "./moebiusTiger.js";
import { facet } from "../assets/lowPoly.js";
import { quatYToDir, latLonToDir, flatXZToLatLon } from "./sphereMath.js";
import { CANYON } from "./canyon.js";
import { PLANET_RADIUS } from "./planet.js";
import { createFisherBoat, updateWarshipOars } from "../assets/harbor.js";

/* ---------------- Y 轴绝对坐标分层（锁死，勿动） ---------------- */
/** 正常球体地面高度：玩家行走的草地 / 坑口缘（湖沼局部坐标，不随 R 放大） */
export const SWAMP_LOCAL_GROUND_Y = 40.0;
/** 兼容旧调用方；语义上仍是局部坐标。 */
export const SWAMP_GROUND_Y = SWAMP_LOCAL_GROUND_Y;
/** 地下半透明湖沼水面高度：比地表低整整 15 单位 */
export const SWAMP_WATER_Y = 25.0;
/** 坑洞最深处湖底沙地：巨树根部与河床乱石扎根于此 */
export const SWAMP_FLOOR_Y = 10.0;
/** 白鲸躯干中心：昂首破水（月夜里水面的亮色主体） */
const WHALE_Y = 24.0;

const WATER_Y = SWAMP_WATER_Y;

/**
 * 植物树叶相对坑口地面的高度倍率。
 * 2 = 树冠/巨叶距地面高度升为原来的 2 倍（仅抬叶冠，不改水面/盆地）。
 */
const LEAF_HEIGHT_MUL = 2;

/** 把「高于地面」的 Y 按 LEAF_HEIGHT_MUL 抬高 */
function leafHeightY(y) {
  if (y <= SWAMP_LOCAL_GROUND_Y) return y;
  return SWAMP_LOCAL_GROUND_Y + (y - SWAMP_LOCAL_GROUND_Y) * LEAF_HEIGHT_MUL;
}

/* ---------------- 月夜色板（深蓝主导 + 萤火/花蕊辉光提亮） ---------------- */
const WATER_COLOR = 0x4aa8ff; // 水面亮蓝（月夜自发光，明确可读为湖水）
const WATER_MID = 0x147acc;   // 水体中段饱和蓝（向下渐深）
const WATER_DEEP = 0x052a6b;  // 深水衰减（暗蓝，越往下越深）
const WALL_COLOR = 0x1b4f5e;  // 坑壁湿暗青蓝
const WALL_MOSS = 0x2a6b70;   // 坑壁苔藓亮斑（月夜微光）
const FLOOR_COLOR = 0x173f52; // 湖底暗蓝沙
const GRASS_COLOR = 0x1d5a50; // 坑缘暗青绿草
const TRUNK_COLOR = 0x16454e; // 墨暗巨干
const VINE_COLOR = 0x2f8f7a;  // 青绿藤蔓
const ROCK_COLOR = 0x1f5664;  // 水下暗蓝乱石
const ROOT_COLOR = 0x10333c;  // 水下焦暗树根
const LOTUS_LEAF = 0x5cb868;  // 荷叶绿（夜色中略亮）
const WHALE_SKIN = 0xd9e6c4;  // 米白浅绿鲸豚肤（画面亮色主体）
const WHALE_BELLY = 0xeef0da; // 鲸腹更浅的米白
const DOLL_SKIN = 0x3a2a24;   // 土著深肤色
const DOLL_HAIR = 0xe5953f;   // 土著橙焰发（夜色暖亮）
const TOWER_TRUNK = 0x1a4a52; // 坑边苍天巨干（暗青蓝）
const TOWER_LEAF = 0x17505e;  // 巨树冠暗叶
const PALM_LEAF = 0x1d5a68;   // 棕榈/芭蕉叶暗青蓝
/* 暖色点缀生物 */
const EEL_COLOR = 0x9fb84f;   // 黄绿鳗形生物
const WORM_COLOR = 0xd75a3a;  // 橙红管状蠕虫
const MUSHROOM_CAP = 0x8f5fa8;// 紫色蘑菇/珊瑚
const MUSHROOM_STEM = 0xcfd8cf;
const PINK_HANG = 0xe88fa2;   // 粉色长尾垂挂生物
const BIRD_PINK = 0xf5c6d0;   // 粉白飞鸟
const BIRD_PURPLE = 0x9a8fb8; // 紫灰飞鸟
const GLOW_BIRD_A = 0xd8ffe0; // 发光飞鸟：薄荷白
const GLOW_BIRD_B = 0xfff0b8; // 发光飞鸟：暖杏黄
const MONKEY_FUR = 0x463a4e;  // 长尾猴：暗紫褐毛
const MONKEY_FACE = 0xe8c8a8; // 长尾猴：浅色脸
const LIZARD_GLOW = 0x8fffc0; // 发光蜥蜴：薄荷绿
const RIBBON_GLOW = 0xc8e860; // 发光带鱼：黄绿
const SHELL_COLOR = 0xe8dcc4; // 米白贝壳
const FISH_GREEN = 0x2f8f6e;  // 绿黑斑纹鱼
const FISH_DARK = 0x0e2f2a;   // 鱼身黑斑/剪影
/* 月夜光源：萤火虫 / 花蕊 / 月光柱 / 树冠分层 */
const FIREFLY_A = 0xd8ff9a;   // 萤火虫黄绿
const FIREFLY_B = 0x9fffe0;   // 萤火虫青蓝
const STAMEN_PINK = 0xffd9e8; // 发光花蕊粉白
const STAMEN_MINT = 0xc8ffe8; // 发光花蕊薄荷
const PETAL_DEEP = 0xb8486a;  // 花瓣深粉
const MOON_SHAFT = 0x9fd4e8;  // 微弱冷月光柱
const CANOPY_DARK = 0x123c4c; // 树冠深色
const CANOPY_MID = 0x17505e;  // 树冠中色
const CANOPY_LIT = 0x1d5f6e;  // 树冠亮色（受月边缘）

/** 通用描边件工厂 */
function part(geo, mat, outline = 0.03) {
  const m = new THREE.Mesh(facet(geo), mat);
  m.castShadow = true;
  m.receiveShadow = true;
  addOutline(m, outline);
  return m;
}

/** 顶点抖动：刀劈斧凿的原始岩壁质感 */
function jitter(geo, amp, rnd) {
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    p.setXYZ(
      i,
      p.getX(i) + (rnd() - 0.5) * amp,
      p.getY(i) + (rnd() - 0.5) * amp * 0.6,
      p.getZ(i) + (rnd() - 0.5) * amp
    );
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * 月夜平涂材质：湖沼不接收全局昼夜光照（树冠遮挡阳光），
 * 用不受光 MeshBasicMaterial 还原参考插画配色（flatShading 对不受光材质无效，忽略）。
 * 沿用 toonMat 之名，最小化调用点改动。
 */
function toonMat(color, opts = {}) {
  const { flatShading, ...rest } = opts || {};
  return new THREE.MeshBasicMaterial({ color, fog: false, ...rest });
}

let _glowTex = null;
/** 径向辉光贴图（单例）：萤火虫 / 花蕊光晕 */
function getGlowTexture() {
  if (_glowTex) return _glowTex;
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.28, "rgba(255,255,255,0.55)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  _glowTex = new THREE.CanvasTexture(c);
  return _glowTex;
}

/** 加色辉光 sprite：萤火虫 / 光晕 / 光池 */
function coralAtmosphereEnabled() {
  return new URLSearchParams(globalThis.location?.search || '').get('gregLakeVisuals') !== '0';
}
function setCoralGlowOpacity(sprite, authoredOpacity) {
  sprite.material.opacity = authoredOpacity * (sprite.userData.coralGlow?.opacityFactor ?? 1);
}
function glowSprite(color, scale, opacity, role = 'ambient') {
  const enabled = coralAtmosphereEnabled();
  const sizeFactor = !enabled || role === 'signal' ? 1 : role === 'large-stamen' ? .45 : .35;
  const opacityFactor = !enabled || role === 'signal' ? 1 : role === 'large-stamen' ? .35 : .2;
  const m = new THREE.SpriteMaterial({
    map: getGlowTexture(),
    color,
    transparent: true,
    opacity: opacity * opacityFactor,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    fog: false,
  });
  const s = new THREE.Sprite(m);
  s.scale.setScalar(scale * sizeFactor);
  s.userData.coralGlow = {role, enabled, authoredScale: scale, authoredOpacity: opacity, sizeFactor, opacityFactor};
  s.raycast = () => {};
  return s;
}

/* =====================================================================
 *  2. 地下半透明 PBR 水体剖面（Y = 25.0）
 *  圆形水面（R=33，贴合坑口）+ 边缘亮圈/高光环，强化“湖”的边界与深邃感
 * ===================================================================== */
function createWaterSurface() {
  // 圆形水面（贴合坑口半径 ~33），而非无限大平面，强化“湖”的边界
  const R = 33;
  const geo = new THREE.CircleGeometry(R, 48);
  geo.rotateX(-Math.PI / 2);
  // 月夜：水面不见阳光，自发光半透明浅蓝；下方透出上浅下深的水体剖面
  const mat = new THREE.MeshBasicMaterial({
    color: new THREE.Color(WATER_COLOR),
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
    depthWrite: false,
    fog: false,
  });
  const water = new THREE.Mesh(geo, mat);
  water.name = "swamp-underground-waterline";
  water.position.y = WATER_Y;
  water.receiveShadow = true;
  addOutline(water, 0.014, INK_COLOR, 0.05);

  // 水面边缘亮圈：明确的水/陆分界线，让“湖面”成为可读的视觉基准
  const rimPts = [];
  for (let i = 0; i <= 64; i++) {
    const a = (i / 64) * Math.PI * 2;
    rimPts.push(new THREE.Vector3(Math.cos(a) * R, 0.05, Math.sin(a) * R));
  }
  const rim = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(rimPts),
    new THREE.LineBasicMaterial({ color: 0x6fd8ff, transparent: true, opacity: 0.65, fog: false })
  );
  rim.raycast = () => {};
  water.add(rim);

  // 微弱高光环（加色发光），增强水面反光与深邃感
  const glowRing = new THREE.Mesh(
    new THREE.RingGeometry(R - 1.2, R + 0.4, 64),
    new THREE.MeshBasicMaterial({
      color: 0x33a8ff, transparent: true, opacity: 0.28,
      side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, fog: false,
    })
  );
  glowRing.rotation.x = -Math.PI / 2;
  glowRing.position.y = 0.06;
  glowRing.raycast = () => {};
  water.add(glowRing);
  return water;
}

/* =====================================================================
 *  2b. 水体体积剖面（Y = 10 → 25）：上浅蓝、下深蓝的垂直渐变
 *  让“水面向下蓝色越深”可读：透过浅蓝半透明水面，可见充填整湖的
 *  水体圆柱，顶=浅蓝(WATER_COLOR) → 中=WATER_MID → 底=深蓝(WATER_DEEP)
 * ===================================================================== */
function createWaterVolume() {
  // 半径略小于坑壁，避免 z-fighting；上口 r≈31、底 r≈14，随坑壁上宽下窄
  const R_TOP = 32.5; // 贴近水面边缘，减少边缘漏出绿色坑壁/草地
  const R_BOT = 14;
  const H = SWAMP_WATER_Y - SWAMP_FLOOR_Y; // 15
  const geo = new THREE.CylinderGeometry(R_TOP, R_BOT, H, 32, 8, true);
  geo.rotateX(0); // 默认 Y 轴向，无需旋转
  // 顶点色：按高度归一化（顶=1，底=0）从浅蓝渐变到深蓝
  const pos = geo.attributes.position;
  const col = new Float32Array(pos.count * 3);
  const cTop = new THREE.Color(WATER_COLOR);
  const cMid = new THREE.Color(WATER_MID);
  const cBot = new THREE.Color(WATER_DEEP);
  const cTmp = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const hgt = THREE.MathUtils.clamp((pos.getY(i) + H / 2) / H, 0, 1); // 0 底 → 1 顶
    if (hgt > 0.5) cTmp.copy(cMid).lerp(cTop, (hgt - 0.5) * 2);
    else cTmp.copy(cBot).lerp(cMid, hgt * 2);
    col[i * 3] = cTmp.r;
    col[i * 3 + 1] = cTmp.g;
    col[i * 3 + 2] = cTmp.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  const mat = new THREE.MeshBasicMaterial({
    vertexColors: true,
    transparent: true,
    opacity: 0.58,
    side: THREE.DoubleSide,
    depthWrite: false,
    fog: false,
  });
  const vol = new THREE.Mesh(geo, mat);
  vol.name = "swamp-water-volume";
  vol.position.y = (SWAMP_WATER_Y + SWAMP_FLOOR_Y) / 2; // 17.5
  vol.raycast = () => {};
  return vol;
}

/* =====================================================================
 *  2c. 水面涟漪波纹：花朵/落叶触水时扩散的细环（加色发光，外扩淡出）
 * ===================================================================== */
function createRipple() {
  // 细环：内半径 0.82、外半径 1.0，靠整体 scale 放大表现扩散
  const geo = new THREE.RingGeometry(0.82, 1.0, 40);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    color: new THREE.Color(0xbfeaff),
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    fog: false,
  });
  const ring = new THREE.Mesh(geo, mat);
  ring.name = "swamp-ripple";
  ring.raycast = () => {};
  ring.visible = false;
  ring.userData = { active: false, age: 0, life: 2.2 };
  return ring;
}

/* =====================================================================
 *  3. 程序化实时拼装「珍珠瓷感异星白鲸」NPC
 *  Thinking in Boxes：卵形身 + 圆鼻头 + 双扁鳍 + 微翘分叉尾
 * ===================================================================== */
// Local actor meshes deliberately use smooth normals and a restrained ink hull.
// Do not change the shared part() factory: trees, props and other worlds retain it.
const CORAL_ACTOR_INK = 0x514b64;
function coralActorMesh(geometry, color, ink = 0.009) {
  const mesh = new THREE.Mesh(geometry, toonMat(color));
  if (ink > 0) addOutline(mesh, ink, CORAL_ACTOR_INK, 0);
  return mesh;
}
function coralEllipsoid(position, scale, color, rotation = [0, 0, 0]) {
  const geometry = new THREE.SphereGeometry(1, 16, 12);
  geometry.scale(...scale);
  geometry.applyMatrix4(new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(...rotation)));
  geometry.translate(...position);
  return {geometry, color};
}
// Rigid anatomical pieces share one draw call; wing/arm pivots remain separate.
function coralActorBatch(pieces, ink = 0.009) {
  const positions = [], normals = [], colors = [];
  for (const piece of pieces) {
    const geometry = piece.geometry.index ? piece.geometry.toNonIndexed() : piece.geometry;
    const c = new THREE.Color(piece.color);
    positions.push(...geometry.attributes.position.array);
    normals.push(...geometry.attributes.normal.array);
    for (let i = 0; i < geometry.attributes.position.count; i++) colors.push(c.r, c.g, c.b);
    if (geometry !== piece.geometry) geometry.dispose();
    piece.geometry.dispose();
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  const mesh = coralActorMesh(geometry, 0xffffff, ink);
  mesh.material.vertexColors = true;
  return mesh;
}

// Small animals need an even pen contour rather than the shared noisy brush
// hull. Pixel width is capped by each real anatomical piece's thin radius, so
// wing tips, toes and tapering tails cannot inflate into dark bands.
function coralFineActorBatch(pieces) {
  const limits=[],outlineNormals=[];
  for(const piece of pieces){
    const source=piece.geometry,geometry=source.index?source.toNonIndexed():source;
    geometry.computeBoundingBox();
    const box=geometry.boundingBox,size=box.getSize(new THREE.Vector3());
    const radius=Math.min(size.x,size.y,size.z)*.5,p=geometry.attributes.position,n=geometry.attributes.normal;
    const welded=new Map(),keys=[];
    for(let i=0;i<p.count;i++){
      const key=[p.getX(i),p.getY(i),p.getZ(i)].map(v=>Math.round(v*1e6)).join(',');keys.push(key);
      if(!welded.has(key))welded.set(key,new THREE.Vector3());
      welded.get(key).add(new THREE.Vector3().fromBufferAttribute(n,i));
    }
    for(const normal of welded.values())normal.normalize();
    const tube=source.parameters?.radialSegments&&source.parameters?.tubularSegments?source:null;
    const rings=[];
    if(tube){
      const original=source.attributes.position,segments=source.parameters.radialSegments;
      for(let j=0;j<=source.parameters.tubularSegments;j++){
        const center=new THREE.Vector3();for(let k=0;k<segments;k++)center.add(new THREE.Vector3().fromBufferAttribute(original,j*(segments+1)+k));
        center.multiplyScalar(1/segments);rings.push(center);
      }
    }
    for(let i=0;i<p.count;i++){
      let thinRadius=radius;
      if(tube){
        const originalIndex=source.index?source.index.getX(i):i,ring=Math.floor(originalIndex/(source.parameters.radialSegments+1));
        thinRadius=new THREE.Vector3().fromBufferAttribute(p,i).distanceTo(rings[ring]);
      }
      limits.push(Math.min(.006,thinRadius*.06));outlineNormals.push(...welded.get(keys[i]));
    }
    if(geometry!==source)geometry.dispose();
  }
  const mesh=coralActorBatch(pieces,0),geometry=mesh.geometry.clone();
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(outlineNormals,3));
  geometry.setAttribute('coralInkLimit',new THREE.Float32BufferAttribute(limits,1));
  const resolution={value:new THREE.Vector2(1,1)},width={value:.85};
  const material=new THREE.MeshBasicMaterial({color:0x435968,side:THREE.BackSide,fog:false,toneMapped:false});
  material.onBeforeCompile=shader=>{
    shader.uniforms.coralInkResolution=resolution;shader.uniforms.coralInkWidth=width;
    shader.vertexShader=shader.vertexShader.replace('#include <common>',`#include <common>
attribute float coralInkLimit;
uniform vec2 coralInkResolution;
uniform float coralInkWidth;`).replace('#include <project_vertex>',`#include <project_vertex>
vec4 inkLimitClip = projectionMatrix * modelViewMatrix * vec4(position + normal * coralInkLimit, 1.0);
if (gl_Position.w > 0.0 && inkLimitClip.w > 0.0) {
  vec2 deltaPixels = (inkLimitClip.xy / inkLimitClip.w - gl_Position.xy / gl_Position.w) * coralInkResolution * .5;
  float availablePixels = length(deltaPixels);
  if (availablePixels > .00001) gl_Position.xy += deltaPixels / availablePixels * min(coralInkWidth, availablePixels) * 2.0 / coralInkResolution * gl_Position.w;
}`);
  };
  material.customProgramCacheKey=()=> 'swamp-fine-animal-ink-v1';
  const outline=new THREE.Mesh(geometry,material);outline.name='swamp-fine-animal-ink';outline.userData.isOutline=true;
  outline.userData.fineAnimalInk={version:1,cssPixels:.85,color:'#435968',radiusFraction:.06,maxLocalExpansion:.006};
  outline.raycast=()=>{};
  outline.onBeforeRender=renderer=>{renderer.getDrawingBufferSize(resolution.value);width.value=.85*renderer.getPixelRatio();};
  mesh.add(outline);return mesh;
}

function buildBelugaWhale(rnd) {
  const whale = new THREE.Group();
  whale.name = "moebius-beluga-whale";
  // A closed axial loft joins forehead, trunk and tail stock without overlapping
  // head spheres or faceted outline normals. Front remains +Z for old animation.
  const profile = [
    [-4.35, .18, .13, .38], [-3.8, .42, .28, .28], [-3.1, .8, .55, .14],
    [-2.2, 1.27, .84, .04], [-1, 1.64, 1.08, 0], [.4, 1.76, 1.18, .03],
    [1.55, 1.54, 1.22, .12], [2.4, 1.16, 1.1, .23], [2.95, .84, .88, .28],
    [3.3, .56, .62, .19], [3.57, .28, .31, .05]
  ];
  const curve = new THREE.CatmullRomCurve3(profile.map(p => new THREE.Vector3(p[1], p[2], p[3])));
  const positions = [], indices = [], slices = 32, rings = 49;
  // Interpolate the actual monotonic Z profile independently of radius spline.
  for (let j = 0; j < rings; j++) {
    const t = j / (rings - 1), u = t * (profile.length - 1), k = Math.min(profile.length - 2, Math.floor(u));
    const z = THREE.MathUtils.lerp(profile[k][0], profile[k + 1][0], u - k), r = curve.getPoint(t);
    for (let i = 0; i < slices; i++) {
      const angle = i / slices * Math.PI * 2;
      positions.push(Math.cos(angle) * r.x, Math.sin(angle) * r.y + r.z, z);
      if (j < rings - 1) { const a = j * slices + i, b = j * slices + (i + 1) % slices;
        indices.push(a, b, a + slices, b, b + slices, a + slices); }
    }
  }
  const back = positions.length / 3; positions.push(0, .38, -4.48);
  const front = positions.length / 3; positions.push(0, .02, 3.72);
  for (let i = 0; i < slices; i++) {
    const next = (i + 1) % slices, base = (rings - 1) * slices;
    indices.push(back, next, i, front, base + i, base + next);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices); geo.computeVertexNormals();
  const body = coralActorMesh(geo, WHALE_SKIN, .012);
  body.name = 'swamp-beluga-continuous-body'; whale.add(body);
  const appendages = [];
  for (const side of [-1, 1]) {
    appendages.push(coralEllipsoid([side * 1.73, -.49, .25], [.95, .12, .43], WHALE_SKIN, [0, side * -.4, side * -.23]));
    appendages.push(coralEllipsoid([side * .73, .45, -4.3], [1.02, .12, .47], WHALE_SKIN, [0, side * .28, side * .08]));
  }
  const fins = coralActorBatch(appendages, .01); fins.name = 'swamp-beluga-rounded-fins'; whale.add(fins);
  // Tiny eyes lie on the forehead side surface, rather than floating beyond it.
  const eyes = coralActorBatch([-1, 1].map(side => coralEllipsoid([side * .887, .43, 2.9], [.045, .07, .075], CORAL_ACTOR_INK)), 0);
  eyes.name = 'swamp-beluga-side-eyes'; whale.add(eyes);
  const mouth = new THREE.Line(new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-.25, -.14, 3.59), new THREE.Vector3(0, -.18, 3.66), new THREE.Vector3(.25, -.14, 3.59)
  ]), new THREE.LineBasicMaterial({color: CORAL_ACTOR_INK}));
  mouth.name = 'swamp-beluga-mouth'; mouth.raycast = () => {}; whale.add(mouth);
  whale.userData.parts = [body, fins, eyes];
  whale.userData.coralActorVersion = 1;
  return whale;
}

/* =====================================================================
 *  4a. 原始世界树（扎根 Y = 10.0）：焦黑墨绿六棱柱 + 蛇形藤蔓
 * ===================================================================== */
function buildWorldTree(rnd, swampZone) {
  const g = new THREE.Group();
  g.name = "swamp-ancient-world-tree";

  const trunkH = 58; // Y=10 → Y=68，上穿水面伸向高空
  const trunk = part(
    new THREE.CylinderGeometry(1.4, 2.6, trunkH, 6), // 六棱柱
    toonMat(TRUNK_COLOR, { flatShading: true }),
    0.05
  );
  trunk.name = "world-tree-trunk";
  trunk.scale.set(1.12, 1, 0.9);
  trunk.position.set(-8, SWAMP_FLOOR_Y + trunkH * 0.5, -7);
  trunk.rotation.z = 0.05;
  trunk.rotation.x = -0.03;
  g.add(trunk);

  // 水下根部：焦黑抓地根须（Y=10 扎根）
  const rootMat = toonMat(ROOT_COLOR, { flatShading: true });
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + rnd() * 0.6;
    const root = part(
      new THREE.ConeGeometry(0.5 + rnd() * 0.3, 3.2 + rnd() * 2.2, 4),
      rootMat,
      0.02
    );
    root.rotation.z = Math.PI + (rnd() - 0.5) * 0.9; // 倒扣扎入沙地
    root.rotation.y = a;
    root.position.set(
      trunk.position.x + Math.cos(a) * 2.2,
      SWAMP_FLOOR_Y + 0.9,
      trunk.position.z + Math.sin(a) * 2.2
    );
    g.add(root);
  }

  // 树冠：水上多层低多边球（Y=52 以上）
  for (let i = 0; i < 7; i++) {
    const canopy = part(
      new THREE.IcosahedronGeometry(2.4 + rnd() * 2.0, 0),
      toonMat(CANOPY_MID, { flatShading: true }),
      0.03
    );
    const a = rnd() * Math.PI * 2;
    const d = 0.8 + rnd() * 4.2;
    canopy.position.set(
      trunk.position.x + Math.cos(a) * d,
      leafHeightY(52 + rnd() * 12),
      trunk.position.z + Math.sin(a) * d
    );
    g.add(canopy);
  }

  // 翠绿藤蔓：绕巨树与水下岩石蛇形缠绕
  const vineMat = toonMat(VINE_COLOR, { flatShading: true });
  const tx = trunk.position.x;
  const tz = trunk.position.z;
  const vineCount = 5 + ((rnd() * 2) | 0);
  for (let v = 0; v < vineCount; v++) {
    const pts = [];
    const phase = rnd() * Math.PI * 2;
    const turns = 1.2 + rnd() * 1.5;
    const y0 = SWAMP_FLOOR_Y + rnd() * 2; // 从水底起步
    const y1 = 44 + rnd() * 14;
    const segs = 14;
    const rad0 = 2.6 + rnd() * 1.4;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      const ang = phase + t * turns * Math.PI * 2;
      const rr = rad0 * (0.88 + 0.22 * Math.sin(t * 6 + phase));
      pts.push(
        new THREE.Vector3(tx + Math.cos(ang) * rr, y0 + (y1 - y0) * t, tz + Math.sin(ang) * rr)
      );
    }
    const tube = part(
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 64, 0.16 + rnd() * 0.12, 5, false),
      vineMat,
      0.018
    );
    tube.name = `swamp-vine-${v}`;
    g.add(tube);
  }

  swampZone.add(g);
  return g;
}

/* =====================================================================
 *  4b. 内凹荷叶小舟（Y = 25.0）：ConeGeometry 翻转 180° 成凹陷浅碗
 * ===================================================================== */
function buildNativeDoll(scale = 1) {
  const doll=new THREE.Group();doll.name="swamp-native-doll";
  const skin=0x282834,hair=0xd9cbb8;
  const pieces=[
    coralEllipsoid([0,.61,0],[.145,.24,.11],skin),
    coralEllipsoid([0,.86,0],[.062,.10,.062],skin),
    coralEllipsoid([0,.98,.015],[.155,.17,.14],skin),
    coralEllipsoid([0,1.095,-.015],[.16,.082,.14],hair),
    coralEllipsoid([-.074,1.102,.082],[.09,.065,.071],hair),
    coralEllipsoid([.082,1.103,.064],[.08,.07,.083],hair),
  ];
  for(const side of [-1,1]){
    pieces.push(coralEllipsoid([side*.153,.98,.008],[.033,.051,.032],skin));
    pieces.push(coralEllipsoid([side*.057,.982,.137],[.011,.014,.006],hair));
  }
  for(const p of pieces)p.geometry.scale(scale,scale,scale);
  const body=coralFineActorBatch(pieces);body.name='swamp-native-child-anatomy';doll.add(body);
  const limbs=[];
  for(const kind of ['arm','leg'])for(const side of [-1,1]){
    const arm=kind==='arm',limb=new THREE.Group();limb.name=`swamp-child-${kind}-${side}`;
    limb.position.set(side*(arm?.13:.072)*scale,(arm?.75:.43)*scale,0);
    const points=arm?[[0,0,0],[side*.12,-.12,.05],[side*.23,-.10,.15]]:[[0,0,0],[side*.015,-.17,.015],[side*.018,-.37,.035]];
    const geometry=faunaTube(points,u=>(arm?.034:.043)*(1-.26*u),16,8);geometry.scale(scale,scale,scale);
    const end=points[2],tip=coralEllipsoid(end,arm?[.039,.045,.045]:[.044,.04,.084],skin);tip.geometry.scale(scale,scale,scale);
    limb.add(coralFineActorBatch([{geometry,color:skin},tip]));doll.add(limb);limbs.push({node:limb,arm,side});
  }
  doll.userData.coralSwimLimbs=limbs;doll.userData.coralFaunaVersion=1;
  return doll;
}

// The flower passengers are the two playful boys in the user's drawing.
// Cache rigid anatomy by pose: three shared meshes per boy, no cone clothing
// and no per-curl draw calls. The legacy swimmer is a separate story actor.
const flowerBoyAssets = new Map();
function flowerBoyGeometry(pose) {
  if (flowerBoyAssets.has(pose)) return flowerBoyAssets.get(pose);
  const skin=0x282834,hair=0xd9cbb8,body=[],head=[],arm=[];
  const ell=(list,p,s,color=skin)=>{
    const geometry=new THREE.SphereGeometry(1,8,6);geometry.scale(...s);geometry.translate(...p);list.push({geometry,color});
  };
  const limb=(list,a,b,r)=>{
    const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b),delta=end.clone().sub(start);
    const geometry=new THREE.SphereGeometry(1,8,6);geometry.scale(r,delta.length()*.5+r*.25,r);
    geometry.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));
    geometry.translate(...start.add(end).multiplyScalar(.5).toArray());list.push({geometry,color:skin});
  };
  ell(body,[0,.18,0],[.22,.16,.17]); // seated pelvis
  ell(body,[0,.45,.035],[.20,.29,.14]);
  limb(body,[0,.62,.06],[0,.75,.09],.075); // visible neck
  for(const side of [-1,1]){
    limb(body,[side*.13,.15,.04],[side*.16,.12,.35],.073);
    limb(body,[side*.16,.12,.35],[side*.17,-.22,.51],.059);
    ell(body,[side*.17,-.25,.59],[.07,.055,.14]);
  }
  limb(body,[-.18,.61,.04],[-.29,.30,.16],.053);
  limb(body,[-.29,.30,.16],[-.27,.05,.25],.046);
  ell(body,[-.27,.035,.27],[.068,.038,.073]);
  ell(head,[0,0,0],[.18,.205,.17]);
  ell(head,[0,-.025,.17],[.055,.043,.05]); // small nose, same black skin
  for(const side of [-1,1])ell(head,[side*.07,.015,.159],[.017,.015,.018],0x11151f);
  // Pale irregular tufts, not the former four orange spheres.
  for(let i=0;i<9;i++){
    const a=i*Math.PI*2/9;
    ell(head,[Math.cos(a)*.155,.13+(i%3)*.016,Math.sin(a)*.135],[.093,.105+(i%2)*.015,.095],hair);
  }
  ell(head,[0,.22,0],[.125,.10,.12],hair);
  if(pose==='play'){
    limb(arm,[0,0,0],[.13,-.32,.30],.052);
    limb(arm,[.13,-.32,.30],[.08,-.76,.60],.046);
    ell(arm,[.08,-.79,.65],[.064,.038,.085]);
  }else{
    limb(arm,[0,0,0],[.17,.16,.12],.052);
    limb(arm,[.17,.16,.12],[.06,.28,.29],.046);
    ell(arm,[.06,.29,.31],[.063,.052,.072]);
  }
  const assets=[body,head,arm].map(pieces=>{
    const mesh=coralActorBatch(pieces,0);return {geometry:mesh.geometry,material:mesh.material};
  });
  flowerBoyAssets.set(pose,assets);return assets;
}

function buildFlowerBoy(pose,scale=1) {
  const boy=new THREE.Group();boy.name='swamp-native-doll';
  const rig=new THREE.Group();rig.name='swamp-flower-boy-rig';rig.scale.setScalar(scale);boy.add(rig);
  const meshes=flowerBoyGeometry(pose).map((asset,i)=>{
    const mesh=new THREE.Mesh(asset.geometry,asset.material);mesh.name=['swamp-boy-body-limbs','swamp-boy-head-hair','swamp-boy-play-arm'][i];rig.add(mesh);return mesh;
  });
  const [,head,arm]=meshes;head.position.set(0,.86,.09);arm.position.set(.18,.61,.04);
  boy.userData.flowerBoy={pose,rig,head,arm,scale,anatomy:['head','neck','torso','leftArm','rightArm','leftHand','rightHand','leftLeg','rightLeg','leftFoot','rightFoot']};
  boy.userData.updateFlowerBoy=time=>{
    head.rotation.y=Math.sin(time*.75+(pose==='play'?0:1.5))*(pose==='play'?.08:.28);
    head.rotation.x=pose==='play'?.20+.04*Math.sin(time):-.06;
    arm.rotation.x=Math.sin(time*1.35+(pose==='play'?0:2))*(pose==='play'?.10:.12);
    arm.rotation.z=pose==='play'?.03*Math.sin(time*.8):.08*Math.sin(time*1.1);
  };
  boy.userData.updateFlowerBoy(0);return boy;
}

function createLotusLeafBoat(rnd, radius = 4.2) {
  const g = new THREE.Group();
  g.name = "swamp-lotus-leaf-boat";

  // Thin closed flower cup: the central floor remains under the old passengers.
  // Eight lobes belong to one continuous wall; no opaque inverse hull fills it.
  const segments = 64, rows = 12, positions = [], colors = [], indices = [];
  const surface = (t, angle, underside = false) => {
    const lobe = .5 + .5 * Math.cos(angle * 8);
    const r = radius * t * (1 - .045 * t ** 6 * (1 - lobe));
    const rise = Math.max(0, (t - .58) / .42);
    const y = .08 + radius * (.18 * rise * rise + .055 * rise ** 3 * lobe);
    return new THREE.Vector3(Math.cos(angle) * r, y - (underside ? radius * .012 : 0), Math.sin(angle) * r);
  };
  // Center is one vertex per side; ring seams share indices for a watertight cup.
  for (let side = 0; side < 2; side++) {
    const c = new THREE.Color(side ? 0x91afa0 : 0xcbdab6), base = positions.length / 3;
    const center = surface(0, 0, !!side); positions.push(...center.toArray()); colors.push(c.r,c.g,c.b);
    for (let row = 1; row <= rows; row++) for (let i = 0; i < segments; i++) {
      const v = surface(row / rows, i / segments * Math.PI * 2, !!side);
      positions.push(...v.toArray()); colors.push(c.r,c.g,c.b);
    }
    const tri = (a,b,c) => indices.push(...(side ? [a,b,c] : [a,c,b]));
    for (let i = 0; i < segments; i++) tri(base, base + 1 + i, base + 1 + (i + 1) % segments);
    for (let row = 1; row < rows; row++) for (let i = 0; i < segments; i++) {
      const a = base + 1 + (row - 1) * segments + i, b = base + 1 + (row - 1) * segments + (i + 1) % segments;
      tri(a,b,a+segments); tri(b,b+segments,a+segments);
    }
  }
  const sideSize = 1 + rows * segments, rim = 1 + (rows - 1) * segments;
  for (let i = 0; i < segments; i++) {
    const a = rim+i,b = rim+(i+1)%segments;
    indices.push(a,b,a+sideSize,b,b+sideSize,a+sideSize);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
  geometry.setIndex(indices); geometry.computeVertexNormals();
  const cup = new THREE.Mesh(geometry, toonMat(0xffffff,{vertexColors:true,side:THREE.DoubleSide}));
  cup.name='swamp-flower-boat-cup';g.add(cup);
  const linePoints = [];
  const lineAt = (t,a) => surface(t,a).add(new THREE.Vector3(0,.007,0));
  for(let i=0;i<segments;i++)linePoints.push(lineAt(1,i*Math.PI*2/segments),lineAt(1,(i+1)*Math.PI*2/segments));
  for(let i=0;i<16;i++)for(let j=1;j<12;j++)linePoints.push(lineAt(j/12,i*Math.PI/8),lineAt((j+1)/12,i*Math.PI/8));
  const veins=new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(linePoints),new THREE.LineBasicMaterial({color:CORAL_ACTOR_INK,transparent:true,opacity:.58}));
  veins.name='swamp-flower-boat-veins';veins.raycast=()=>{};g.add(veins);
  g.userData.flowerCup={radius,floorY:.08,flatRadius:radius*.58,version:1};

  // Keep the old RNG budget, but the approved story now fixes exactly two boys.
  const oldDollN=2+((rnd()*2)|0),oldScales=[];
  for(let i=0;i<oldDollN;i++){oldScales.push(.85+rnd()*.4);rnd();rnd();rnd();}
  g.userData.passengers=[];
  for(let i=0;i<2;i++){
    const boy=buildFlowerBoy(i===0?'play':'look',oldScales[i]*1.15),side=i===0?1:-1;
    boy.position.set(0,.1,side*radius*.50);boy.rotation.y=i===0?0:Math.PI;
    const rig=boy.userData.flowerBoy.rig;
    rig.position.set(0,surface(.84,i===0?Math.PI/2:-Math.PI/2).y-.1,radius*.34);
    g.add(boy);g.userData.passengers.push(boy);
  }

  installFlowerBoatPaddles(g,radius);

  // 参考图叶舟中的粉色发光花蕊尖锥
  const spike = buildStamenSpike(rnd);
  spike.position.set(-radius * 0.25, 0.12, radius * 0.1);
  spike.rotation.z = 0.12;
  g.add(spike);
  g.userData.halo = spike.userData.halo;

  return g;
}

/* =====================================================================
 *  4c. 参考插画生态组件：鳗/管虫/紫蘑菇/粉垂生物/飞鸟/贝壳/棕榈
 * ===================================================================== */
/** 黄绿鳗形生物：水下蛇形游动（CatmullRom 管体，头部圆钝） */
function buildSwampEel(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-eel";
  const pts = [];
  const phase = rnd() * Math.PI * 2;
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    pts.push(new THREE.Vector3(
      t * 11 - 5.5,
      Math.sin(t * Math.PI * 2 + phase) * 1.2,
      Math.cos(t * Math.PI * 1.4 + phase) * 1.6
    ));
  }
  const skin=0xa8b58b,head=pts[8].clone().add(new THREE.Vector3(.24,0,0));
  const pieces=[{geometry:faunaTube(pts,u=>.006+.285*(1-Math.exp(-u*6)),48,12),color:skin},coralEllipsoid(head.toArray(),[.49,.28,.275],skin)];
  pieces.push(coralEllipsoid([head.x+.08,head.y-.14,head.z],[.35,.085,.225],0xd5d5ae));
  for (const side of [-1, 1]) {
    pieces.push(coralEllipsoid([head.x+.21,head.y+.09,head.z+side*.242],[.035,.038,.015],0x435968));
    pieces.push(coralEllipsoid([head.x-.29,head.y-.08,head.z+side*.30],[.26,.035,.13],0xc5cba3,[side*.2,side*.3,0]));
  }
  const anatomy=coralFineActorBatch(pieces);anatomy.name='swamp-eel-smooth-anatomy';g.add(anatomy);
  g.userData.phase = phase;
  g.userData.coralFaunaVersion=1;
  return g;
}

/** 橙红管状蠕虫丛：湖底扎根，顶端微张 */
function buildTubeWormCluster(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-tube-worms";
  const pieces=[];
  const n = 4 + ((rnd() * 4) | 0);
  for (let i = 0; i < n; i++) {
    const h = 1.1 + rnd() * 1.6;
    const top=.13+rnd()*.07,bottom=.2+rnd()*.08;
    const a = rnd() * Math.PI * 2;
    const d = rnd() * 0.9;
    const leanZ=(rnd()-.5)*.3,leanX=(rnd()-.5)*.3,tipR=.16+rnd()*.06;
    const x=Math.cos(a)*d,z=Math.sin(a)*d,tip=[x+leanZ*h*.6,h,z-leanX*h*.6];
    pieces.push({geometry:faunaTube([[x,0,z],[x+leanZ*h*.2,h*.42,z-leanX*h*.2],[tip[0]-.06*Math.sin(i),h*.78,tip[2]],tip],u=>THREE.MathUtils.lerp(bottom*.73,top*.72,u),20,10),color:i%2?0xc98d8a:0xc5a193});
    pieces.push(coralEllipsoid(tip,[tipR*.90,tipR*.75,tipR*.90],0xf0cbb5));
    pieces.push(coralEllipsoid([tip[0],tip[1]+tipR*.55,tip[2]],[tipR*.45,tipR*.22,tipR*.45],0xf4dfb9));
  }
  const anatomy=coralFineActorBatch(pieces);anatomy.name='swamp-soft-tube-worm-anatomy';g.add(anatomy);g.userData.coralTubeCount=n;g.userData.coralFaunaVersion=1;
  return g;
}

/** 紫色蘑菇/珊瑚状植物（坑缘与水下皆可） */
function buildMoebiusMushroom(rnd, scale = 1) {
  const g = new THREE.Group();
  g.name = "swamp-mushroom";
  const h = (0.9 + rnd() * 1.2) * scale;
  const stem = part(
    new THREE.CylinderGeometry(0.12 * scale, 0.18 * scale, h, 5),
    toonMat(MUSHROOM_STEM, { flatShading: true }),
    0.014
  );
  stem.position.y = h / 2;
  g.add(stem);
  const capR = (0.42 + rnd() * 0.4) * scale;
  const cap = part(new THREE.SphereGeometry(capR, 7, 5, 0, Math.PI * 2, 0, Math.PI * 0.55), toonMat(MUSHROOM_CAP, { flatShading: true }), 0.018);
  cap.position.y = h;
  g.add(cap);
  if (rnd() > 0.4) {
    const h2 = h * 0.6;
    const stem2 = part(new THREE.CylinderGeometry(0.08 * scale, 0.12 * scale, h2, 5), toonMat(MUSHROOM_STEM, { flatShading: true }), 0.01);
    stem2.position.set(capR * 0.9, h2 / 2, capR * 0.4);
    g.add(stem2);
    const cap2 = part(new THREE.SphereGeometry(capR * 0.6, 6, 4, 0, Math.PI * 2, 0, Math.PI * 0.55), toonMat(MUSHROOM_CAP, { flatShading: true }), 0.012);
    cap2.position.set(capR * 0.9, h2, capR * 0.4);
    g.add(cap2);
  }
  return g;
}

/** 粉色长尾垂挂生物：悬于藤蔓下，随风轻摆（蛞蝓/水母感） */
function buildPinkHanger(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-pink-hanger";
  const skin=0xd3a0ab,pieces=[];
  pieces.push({geometry:faunaTube([[0,.03,-.03],[.035,-.30,0],[-.035,-.68,.03],[0,-1.1,.025]],u=>.035+.22*Math.pow(Math.sin(Math.PI*u),.65),24,12),color:skin});
  const tailPts = [
    new THREE.Vector3(0, -0.9, 0),
    new THREE.Vector3(0.18, -1.7, 0.08),
    new THREE.Vector3(-0.12, -2.6, -0.06),
    new THREE.Vector3(0.1, -3.4, 0.05),
  ];
  pieces.push({geometry:faunaTube(tailPts,u=>.006+.079*Math.pow(1-u,.8),28,10),color:skin});
  for (const side of [-1, 1]) {
    pieces.push({geometry:faunaTube([[side*.12,-.34,.01],[side*.31,-.13,.025],[side*.27,.055,-.02],[side*.18,.07,-.07]],u=>.023+.02*(1-u),16,8),color:skin});
    pieces.push(coralEllipsoid([side*.088,-.48,.258],[.021,.026,.014],0x435968));
  }
  const anatomy=coralFineActorBatch(pieces);anatomy.name='swamp-pink-clinging-anatomy';g.add(anatomy);g.userData.coralFaunaVersion=1;
  g.userData.phase = rnd() * Math.PI * 2;
  return g;
}

/** 发光飞鸟：薄荷白 / 暖杏黄 + 加色光晕，枝头间来回穿梭 */
function buildSwampBird(rnd, color) {
  const g = new THREE.Group();
  g.name = "swamp-bird";
  // Latest direction: the accepted anatomy stays pale green; only the head emits pink light.
  const head=0xd8ffe0,breast=0xd8ffe0,wingColor=0xd8ffe0,tailColor=0xd8ffe0,featherLight=0xd8ffe0;
  const pieces = [
    coralEllipsoid([0,0,0],[.24,.22,.51],breast),
    coralEllipsoid([0,.14,.43],[.21,.2,.25],head),
    coralEllipsoid([0,.11,.68],[.065,.07,.21],0x8a7782),
    coralEllipsoid([-.095,.01,-.6],[.085,.04,.3],tailColor,[0,-.14,0]),
    coralEllipsoid([.095,.01,-.6],[.085,.04,.3],tailColor,[0,.14,0]),
    ...[-1,1].map(side=>coralEllipsoid([side*.183,.19,.48],[.028,.033,.033],CORAL_ACTOR_INK))
  ];
  const body=coralFineActorBatch(pieces);body.name='swamp-bird-anatomy';g.add(body);
  for(const side of [-1,1]) {
    const wing=coralFineActorBatch([
      coralEllipsoid([side*.44,0,-.03],[.62,.055,.29],wingColor,[0,side*.25,0]),
      coralEllipsoid([side*.85,-.015,-.23],[.42,.035,.12],featherLight,[0,side*.45,0])
    ]);
    wing.position.set(side*.17,.08,0);wing.rotation.z=side*.5;
    wing.userData.side=side;wing.name='swamp-bird-wing';g.add(wing);
    g.userData[`wing${side>0?'R':'L'}`]=wing;
  }
  // User correction: preserve skin colours; fluorescence comes from the head.
  applySwampInternalGlow(body,{center:[0,.14,.43],radius:[.21,.2,.25],strength:.95,region:'bird-head'});
  for(const wing of [g.userData.wingL,g.userData.wingR])wing.material.toneMapped=false;
  const halo=glowSprite(0x91efce,1.12,.38,'signal');halo.visible=false;
  g.add(halo);g.userData.halo=halo;
  g.userData.orbitR = 15 + rnd() * 11;
  g.userData.orbitY = 44 + rnd() * 7;
  g.userData.dart = 2.5 + rnd() * 3.5;
  g.userData.speed = 0.22 + rnd() * 0.18;
  g.userData.phase = rnd() * Math.PI * 2;
  g.userData.coralActorVersion=1;
  return g;
}

/* 玩家入沼交互（萤火环绕/尾随 + 长尾猴投果 / 送信人回扔 / 猴躲避） */
const FRUIT_G = 12; // 果实弹道重力
const FRUIT_CATCH_R2 = 1.35; // 接住半径²
const FRUIT_HIT_MONKEY_R2 = 1.8; // 砸中猴半径²
const FRUIT_DODGE_R = 7.5; // 猴开始躲避的距离
const _ffP = new THREE.Vector3(); // 玩家局部坐标
const _ffF = new THREE.Vector3(); // 玩家局部朝向（水平）
const _ffQ = new THREE.Quaternion();
const _ffAim = new THREE.Vector3();
const _ffTmp = new THREE.Vector3();
const _syV1 = new THREE.Vector3(); // 战船维修厂动画临时向量
const _syV2 = new THREE.Vector3();
const _raidV1 = new THREE.Vector3(); // 湖沼生物袭击机队临时向量
const _raidV2 = new THREE.Vector3();

/** 长尾猴：暗毛浅脸 + S 形长尾，树冠间跳跃 */
function buildLongTailMonkey(rnd, {tailPose='hanging', tailRise=false} = {}) {
  const g = new THREE.Group();
  g.name = "swamp-longtail-monkey";
  // Approved hanging-climber reference: narrow pink/mauve body, small face,
  // grasping hands and a downward tail. Existing shoulder pivots stay exact.
  const fur=0x9b7c96,shade=0x856d82,face=0xc9b5ad;
  const pieces=[
    coralEllipsoid([0,.56,-.025],[.18,.47,.16],fur),
    coralEllipsoid([0,.9,.015],[.13,.23,.13],fur),
    coralEllipsoid([0,1.12,.025],[.153,.18,.143],fur),
    coralEllipsoid([0,1.11,.15],[.103,.111,.028],face),
    coralEllipsoid([0,1.075,.184],[.022,.014,.018],shade),
    coralEllipsoid([0,.57,.124],[.098,.27,.022],0xb396a6)
  ];
  for(const side of [-1,1]){
    pieces.push(coralEllipsoid([side*.148,1.14,.013],[.047,.064,.035],fur));
    pieces.push(coralEllipsoid([side*.159,1.14,.042],[.023,.038,.012],face));
    pieces.push(coralEllipsoid([side*.042,1.139,.177],[.010,.013,.009],0x435968));
    // Folded narrow thigh and a long grasping foot keep the original perch
    // support envelope, instead of broad seated toy haunches.
    pieces.push(coralEllipsoid([side*.13,.23,-.08],[.074,.245,.09],shade,[.32,0,side*.23]));
    pieces.push(coralEllipsoid([side*.153,.028,.018],[.055,.046,.16],fur));
    for(let toe=-1;toe<=1;toe++)pieces.push(coralEllipsoid([side*.153+toe*.031,.014,.149],[.016,.023,.056],fur,[.15,0,0]));
    // The preserved animation pivot is outside the newly slender torso. A
    // real shoulder bridge reaches that exact pivot and a small joint covers
    // it in every existing lift/throw rotation. The arm itself is continuous.
    pieces.push({geometry:faunaTube([[side*.11,.73,.075],[side*.20,.715,.106],[side*.27,.7,.13]],t=>.051-.003*t,10,8),color:fur});
    pieces.push(coralEllipsoid([side*.27,.7,.13],[.056,.056,.056],fur));
    const armChain=[[0,0,0],[-side*.065,-.17,.018],[-side*.085,-.31,.028],[-side*.064,-.5,.094]];
    const armPieces=[
      {geometry:faunaTube(armChain,t=>.049-.015*t,24,10),color:fur},
      coralEllipsoid([-side*.064,-.5,.094],[.044,.064,.047],shade)
    ];
    for(let finger=-1;finger<=1;finger++){
      const x=-side*.064+finger*.024;
      const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(x,-.53,.11),new THREE.Vector3(x,-.585,.145),new THREE.Vector3(x,-.58,.18)]);
      armPieces.push({geometry:new THREE.TubeGeometry(curve,5,.012,5,false),color:fur});
    }
    const armTubeVertexCount=armPieces[0].geometry.index.count;
    const arm=coralFineActorBatch(armPieces);
    arm.position.set(side*.27,.7,.13);arm.rotation.x=-.3;
    arm.userData.baseRotX=-.3;arm.name='swamp-monkey-arm';g.add(arm);
    arm.userData.monkeyArmChain={version:3,points:armChain,tubeVertexCount:armTubeVertexCount,shoulderBridge:[[side*.11,.73,.075],[side*.27,.7,.13]],jointRadius:.056};
    g.userData[side<0?'armL':'armR']=arm;
  }
  let points=[new THREE.Vector3(0,.37,-.14),new THREE.Vector3(-.13,.02,-.21),new THREE.Vector3(-.16,-.57,-.23),new THREE.Vector3(-.07,-1.25,-.2),new THREE.Vector3(.09,-1.89,-.15),new THREE.Vector3(.27,-1.95,-.12),new THREE.Vector3(.35,-1.83,-.12)];
  const hangingLength=new THREE.CatmullRomCurve3(points).getLength();
  if(tailPose==='deck'){
    // The same long tail coils behind the heels. Preserve its arc length;
    // the low coil clears the footplane even during the existing -.18 lift lean.
    const coil=radius=>{
      const p=[new THREE.Vector3(0,.37,-.14)];
      for(let k=0;k<=10;k++){
        const a=Math.PI*.5+k/10*Math.PI*1.8,r=radius*(1-.2*k/10);
        if(tailRise){
          // The mast worker counter-rotates around a yawed axis. A low flat
          // loop would tilt through the deck; coil up beside the left hip.
          const angle=-Math.PI*.5+k/10*Math.PI*1.8;
          p.push(new THREE.Vector3(-radius+.025+Math.cos(angle)*r,.4+radius*.82+Math.sin(angle)*r*.82,-.14));
        }else p.push(new THREE.Vector3(Math.cos(a)*r,.24+.025*Math.sin(k/10*Math.PI),-.14-radius+Math.sin(a)*r));
      }
      return p;
    };
    let low=.1,high=.8;
    for(let i=0;i<24;i++){
      const radius=(low+high)/2;
      if(new THREE.CatmullRomCurve3(coil(radius)).getLength()<hangingLength)low=radius;else high=radius;
    }
    points=coil((low+high)/2);
  }
  const curve=new THREE.CatmullRomCurve3(points),tail=new THREE.TubeGeometry(curve,40,.039,8,false),position=tail.attributes.position;
  const tailVertexStart=pieces.reduce((n,p)=>n+(p.geometry.index?.count??p.geometry.attributes.position.count),0);
  for(let j=0;j<=40;j++){
    const centre=curve.getPointAt(j/40),taper=1-.68*j/40;
    for(let k=0;k<=8;k++){const i=j*9+k,v=new THREE.Vector3().fromBufferAttribute(position,i).sub(centre).multiplyScalar(taper).add(centre);position.setXYZ(i,v.x,v.y,v.z);}
  }
  tail.computeVertexNormals();pieces.push({geometry:tail,color:fur});
  pieces.push(coralEllipsoid(points.at(-1).toArray(),[.013,.013,.013],fur));
  const body=coralFineActorBatch(pieces);body.name='swamp-monkey-anatomy';g.add(body);
  g.userData.phase=rnd()*Math.PI*2;g.userData.coralActorVersion=2;
  g.userData.monkeyTail={pose:tailPose==='deck'?'deck':'hanging',raisedCoil:tailRise,arcLength:curve.getLength(),hangingLength,vertexStart:tailVertexStart,vertexCount:body.geometry.attributes.position.count-tailVertexStart};
  return g;
}

/** 发光蜥蜴：薄荷绿平涂 + 细尾四足 + 微光晕，地面缓爬 */
function buildGlowLizard(rnd) {
  const g=new THREE.Group();g.name='swamp-glow-lizard';
  const pieces=[
    coralEllipsoid([0,.18,0],[.24,.15,.48],LIZARD_GLOW),
    coralEllipsoid([0,.17,.48],[.155,.115,.27],LIZARD_GLOW),
    coralEllipsoid([0,.135,.64],[.11,.07,.14],LIZARD_GLOW)
  ];
  for(const side of [-1,1]){
    pieces.push(coralEllipsoid([side*.135,.225,.54],[.027,.033,.035],CORAL_ACTOR_INK));
    for(const z of [-.27,.27]){
      pieces.push(coralEllipsoid([side*.25,.105,z],[.19,.055,.075],LIZARD_GLOW,[0,side*(z>0?-.5:.5),0]));
      pieces.push(coralEllipsoid([side*.37,.05,z-.05],[.07,.045,.12],LIZARD_GLOW));
      for(let toe=-1;toe<=1;toe++)pieces.push(coralEllipsoid([side*(.38+toe*.045),.024,z+.04],[.019,.018,.073],LIZARD_GLOW,[0,side*toe*.2,0]));
    }
  }
  const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(0,.15,-.34),new THREE.Vector3(.07,.13,-.65),new THREE.Vector3(.09,.1,-1.02),new THREE.Vector3(-.07,.08,-1.46)]);
  const tail=new THREE.TubeGeometry(curve,24,.085,8,false),pos=tail.attributes.position;
  for(let j=0;j<=24;j++){const center=curve.getPointAt(j/24),taper=1-.92*j/24;for(let i=0;i<=8;i++){const idx=j*9+i,v=new THREE.Vector3().fromBufferAttribute(pos,idx).sub(center).multiplyScalar(taper).add(center);pos.setXYZ(idx,v.x,v.y,v.z);}}
  tail.computeVertexNormals();pieces.push({geometry:tail,color:LIZARD_GLOW});
  pieces.push(coralEllipsoid([-.07,.08,-1.46],[.007,.007,.007],LIZARD_GLOW));
  const body=coralFineActorBatch(pieces);body.name='swamp-lizard-anatomy';g.add(body);
  applySwampInternalGlow(body,{center:[0,.18,0],radius:[.24,.15,.48],strength:.85,region:'lizard-torso'});
  const halo=glowSprite(LIZARD_GLOW,1.5,.4);halo.visible=false;halo.position.y=.3;g.add(halo);g.userData.halo=halo;
  g.userData.phase=rnd()*Math.PI*2;g.userData.coralActorVersion=1;
  return g;
}

// A leaf is an open blade, never a back-face extrusion of a rectangular plane.
// The narrow central strip is part of the same mesh, so it adds no draw call.
function createSwampLooseLeaf(width, height) {
  const boundary=[[-.5,0],[-.3,-.34],[0,-.5],[.3,-.34],[.5,0],[.3,.34],[0,.5],[-.3,.34]];
  const positions=[],colors=[],base=new THREE.Color(PALM_LEAF),vein=new THREE.Color(0x514b64);
  const triangle=(a,b,c,color)=>{for(const v of [a,b,c]){positions.push(v[0]*width,v[1]*height,v[2]||0);colors.push(color.r,color.g,color.b);}};
  for(let i=0;i<boundary.length;i++)triangle([0,0],boundary[i],boundary[(i+1)%boundary.length],base);
  triangle([-.45,0,.002],[.35,-.012,.002],[.46,0,.002],vein);
  triangle([-.45,0,.002],[.46,0,.002],[.35,.012,.002],vein);
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.computeVertexNormals();
  return new THREE.Mesh(geo,toonMat(0xffffff,{vertexColors:true,side:THREE.DoubleSide}));
}

/** 发光带鱼：侧扁长带 + 顶点波动摆尾，水下环游 */
function buildRibbonFish(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-glow-ribbonfish";
  const skin=0xc3cbb0,geometry=faunaTube([[-1.9,0,0],[-.9,.02,0],[.8,.02,0],[1.9,.01,0]],u=>.012+.10*Math.pow(Math.sin(Math.PI*u),.6)+.065*Math.exp(-Math.pow((u-.90)/.12,2)),36,10);geometry.scale(1,1.65,.58);
  const pieces=[{geometry,color:skin},coralEllipsoid([1.84,.016,0],[.13,.10,.064],skin),coralEllipsoid([-1.92,0,0],[.26,.135,.013],0xd9d5b4)];
  for(const side of[-1,1])pieces.push(coralEllipsoid([1.78,.045,side*.060],[.023,.025,.012],0x435968));
  // Same original long body/tail and swim phase; four lateral limbs identify
  // this authored creature as a salamander. Merge toes into the original draw.
  const limbs=[];
  for(const [pair,x]of [['front',1.04],['rear',-.92]])for(const side of [-1,1]){
    const start=pieces.reduce((sum,p)=>sum+(p.geometry.index?p.geometry.index.count:p.geometry.attributes.position.count),0);
    pieces.push({geometry:faunaTube([[x,.015,side*.05],[x-.13,-.04,side*.19],[x-.06,-.07,side*.32]],u=>.018+.024*(1-u),14,8),color:skin});
    for(let toe=-1;toe<=1;toe++)pieces.push({geometry:faunaTube([[x-.06,-.07,side*.30],[x+.025+toe*.055,-.08,side*.37],[x+.065+toe*.075,-.075,side*(.41-Math.abs(toe)*.018)]],u=>.004+.010*(1-u),8,6),color:skin});
    const end=pieces.reduce((sum,p)=>sum+(p.geometry.index?p.geometry.index.count:p.geometry.attributes.position.count),0);
    limbs.push({pair,side,toes:3,vertexStart:start,vertexCount:end-start,anchor:[x,.015,side*.05]});
  }
  const bodyMesh=coralFineActorBatch(pieces);bodyMesh.name='swamp-ribbon-fish-smooth-anatomy';
  const pos=bodyMesh.geometry.attributes.position,baseX=new Float32Array(pos.count),baseZ=new Float32Array(pos.count);
  for(let i=0;i<pos.count;i++){baseX[i]=pos.getX(i);baseZ[i]=pos.getZ(i);}
  bodyMesh.geometry.computeBoundingSphere();bodyMesh.geometry.boundingSphere.radius+=.35;
  // The outline follows the same animated positions, never a stale flat sheet.
  for(const child of bodyMesh.children)if(child.userData.isOutline){child.geometry.setAttribute('position',pos);child.geometry.boundingSphere=bodyMesh.geometry.boundingSphere.clone();}
  g.add(bodyMesh);
  const emission=applySwampInternalGlow(bodyMesh,{center:[1.84,.016,0],radius:[.19,.14,.12],strength:.45,region:'salamander-head'});
  const headLight={enabled:true,intensity:.45};
  g.userData.headLight=headLight;
  g.userData.setHeadLight=(enabled,intensity=headLight.intensity)=>{
    headLight.enabled=!!enabled;headLight.intensity=THREE.MathUtils.clamp(Number.isFinite(intensity)?intensity:.45,0,1);
    emission.setStrength(headLight.enabled?headLight.intensity:0);return headLight;
  };
  g.userData.salamanderLimbs=limbs;
  // Keep the old animation reference but retire its misplaced body/tail halo.
  const halo = glowSprite(0xd8ddb9, .8, .24);halo.visible=false;halo.position.set(1.84,.016,0);
  g.add(halo);
  g.userData.halo = halo;
  g.userData.bodyMesh = bodyMesh;
  g.userData.baseX = baseX;
  g.userData.baseZ = baseZ;
  g.userData.coralFaunaVersion=1;
  g.userData.phase = rnd() * Math.PI * 2;
  return g;
}

/** 米白贝壳（扇面压扁 + 放射刻线） */
function buildShell(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-shell";
  const shell = part(new THREE.SphereGeometry(0.5 + rnd() * 0.25, 8, 5), toonMat(SHELL_COLOR, { flatShading: true }), 0.016);
  shell.scale.set(1, 0.35, 0.85);
  g.add(shell);
  const ridge = part(new THREE.TorusGeometry(0.42, 0.045, 4, 8, Math.PI), toonMat(0xdccfb4, { flatShading: true }), 0.01);
  ridge.rotation.x = Math.PI / 2;
  ridge.position.y = 0.12;
  g.add(ridge);
  return g;
}

/** 坑缘棕榈/丛林树：弯曲青褐干 + 放射棕榈叶丛（湿润繁茂感） */
function buildRimPalm(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-rim-palm";
  // 叶冠距地面高度 ×2
  const h = (7 + rnd() * 6) * LEAF_HEIGHT_MUL;
  const trunkGeo = new THREE.CylinderGeometry(0.28, 0.5, h, 6);
  trunkGeo.translate(0, h / 2, 0);
  trunkGeo.rotateZ(0.12 + rnd() * 0.14); // 微微弯向坑心
  const trunk = part(trunkGeo, toonMat(TOWER_TRUNK, { flatShading: true }), 0.024);
  trunk.userData.swampTreePart = 'palm-trunk';
  g.add(trunk);
  const leafMat = toonMat(PALM_LEAF, { flatShading: true, side: THREE.DoubleSide });
  const top = new THREE.Vector3(-Math.sin(0.12 + 0.14) * h * 0.5, h * 0.98, 0);
  const n = 6 + ((rnd() * 3) | 0);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + rnd() * 0.4;
    const leaf = part(new THREE.PlaneGeometry(0.85, 3.6 + rnd() * 1.6, 1, 3), leafMat, 0.014);
    leaf.geometry.translate(0, -1.9, 0); // 以叶柄为轴下垂
    leaf.position.copy(top);
    leaf.rotation.order = "YXZ";
    leaf.rotation.y = a;
    leaf.rotation.x = 0.85 + rnd() * 0.5; // 外展下垂
    leaf.userData.swampTreePart = 'palm-leaf';
    g.add(leaf);
  }
  return g;
}

/**
 * 坑边苍天巨树（有机整容版）
 * - 六棱主干下粗上细收分 + 露根
 * - 树枝斜向外上 25°~45°，根部嵌进主干 ≥0.3（消灭 90° 直角插接）
 * - 枝端扁平 Icosahedron 树冠 · 深松绿
 * - Toon flatShading + outline 0.045
 */
function buildToweringTree(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-towering-tree";
  const OUT = 0.045;
  const barkMat = toonMat(0x654321, { flatShading: true });
  const barkDark = toonMat(TOWER_TRUNK, { flatShading: true });
  const canopyMats = [
    toonMat(0x1c3024, { flatShading: true }),
    toonMat(0x243a2c, { flatShading: true }),
    toonMat(0x16261c, { flatShading: true }),
  ];
  const yAxis = new THREE.Vector3(0, 1, 0);
  const _d = new THREE.Vector3();

  const h = (40 + rnd() * 18) * LEAF_HEIGHT_MUL; // 高耸
  const R_BOT = 1.2 + rnd() * 0.35;
  const R_TOP = 0.55 + rnd() * 0.2;
  const lean = (rnd() - 0.5) * 0.14;

  function cylSeg(a, b, r0, r1, mat, outline = OUT) {
    _d.subVectors(b, a);
    const len = Math.max(0.05, _d.length());
    const mesh = part(
      new THREE.CylinderGeometry(r1, r0, len, 6, 1, false),
      mat,
      outline
    );
    mesh.position.copy(a).addScaledVector(_d.normalize(), len * 0.5);
    mesh.quaternion.setFromUnitVectors(yAxis, _d);
    mesh.userData.swampTreePart = 'branch';
    g.add(mesh);
    return mesh;
  }

  // —— 主干分段收分（微弯）——
  const trunkPts = [];
  const nSeg = 6;
  for (let i = 0; i <= nSeg; i++) {
    const t = i / nSeg;
    const y = t * h;
    const bend = Math.sin(t * Math.PI) * lean * h * 0.08;
    trunkPts.push(new THREE.Vector3(bend, y, bend * 0.4));
  }
  for (let i = 0; i < trunkPts.length - 1; i++) {
    const t0 = i / (trunkPts.length - 1);
    const t1 = (i + 1) / (trunkPts.length - 1);
    cylSeg(
      trunkPts[i],
      trunkPts[i + 1],
      THREE.MathUtils.lerp(R_BOT, R_TOP, t0),
      THREE.MathUtils.lerp(R_BOT, R_TOP, t1),
      barkMat,
      OUT
    ).userData.swampTreePart = 'trunk';
  }

  // 露根
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + rnd() * 0.4;
    const len = 1.6 + rnd() * 1.4;
    const root = part(
      new THREE.BoxGeometry(len, 0.35 + rnd() * 0.2, 0.5 + rnd() * 0.25),
      barkDark,
      OUT * 0.85
    );
    root.position.set(Math.cos(a) * R_BOT * 0.45, 0.12, Math.sin(a) * R_BOT * 0.45);
    root.rotation.y = a + Math.PI / 2;
    root.rotation.z = (rnd() - 0.5) * 0.3;
    root.userData.swampTreePart = 'root';
    g.add(root);
  }

  function plumeCanopy(at, dir, size) {
    const n = 2 + ((rnd() * 2) | 0);
    for (let k = 0; k < n; k++) {
      const blob = part(
        new THREE.IcosahedronGeometry(0.55, 0),
        canopyMats[k % canopyMats.length],
        OUT * 0.8
      );
      blob.position.copy(at).addScaledVector(dir, 0.4 + k * 0.35);
      blob.position.y += (k - 0.4) * 0.5 * size;
      blob.scale.set(
        (2.0 + rnd() * 0.8) * size,
        (0.35 + rnd() * 0.12) * size,
        (1.5 + rnd() * 0.6) * size
      );
      blob.rotation.set((rnd() - 0.5) * 0.3, rnd() * Math.PI, (rnd() - 0.5) * 0.25);
      g.add(blob);
    }
  }

  // —— 斜向外上树枝（嵌套进主干）——
  const arms = 7 + ((rnd() * 4) | 0);
  for (let i = 0; i < arms; i++) {
    const t = 0.22 + (i / arms) * 0.62 + (rnd() - 0.5) * 0.04;
    const yi = Math.min(trunkPts.length - 2, Math.floor(t * (trunkPts.length - 1)));
    const tf = t * (trunkPts.length - 1) - yi;
    const attach = trunkPts[yi].clone().lerp(trunkPts[yi + 1], tf);
    const trunkR = THREE.MathUtils.lerp(R_BOT, R_TOP, t);

    const elev = 0.45 + rnd() * 0.35; // 25°~45°+ 斜上
    const yaw = (i / arms) * Math.PI * 2 + rnd() * 0.5;
    const dir = new THREE.Vector3(
      Math.cos(yaw) * Math.cos(elev),
      Math.sin(elev),
      Math.sin(yaw) * Math.cos(elev)
    ).normalize();

    const nest = 0.4 + rnd() * 0.35; // ≥0.3 嵌进主干
    const start = attach.clone().addScaledVector(dir, trunkR * 0.1 - nest);
    const len = 8 + rnd() * 10 + (1 - t) * 6;
    const mid = start
      .clone()
      .addScaledVector(dir, len * 0.5)
      .add(new THREE.Vector3((rnd() - 0.5) * 1.2, 0.8 + rnd(), (rnd() - 0.5) * 1.2));
    const tip = start
      .clone()
      .addScaledVector(dir, len)
      .add(new THREE.Vector3((rnd() - 0.5) * 0.8, 1.2 + rnd(), (rnd() - 0.5) * 0.8));

    const r0 = 0.45 + rnd() * 0.2 + (1 - t) * 0.25;
    cylSeg(start, mid, r0, r0 * 0.55, barkMat, OUT * 0.9);
    cylSeg(mid, tip, r0 * 0.55, r0 * 0.22, barkDark, OUT * 0.75);
    plumeCanopy(tip, dir, 2.2 + rnd() * 1.4 + (1 - t) * 0.8);

    // 二级斜枝
    if (rnd() > 0.4) {
      const sub = dir
        .clone()
        .applyAxisAngle(yAxis, (rnd() > 0.5 ? 1 : -1) * (0.55 + rnd() * 0.5));
      sub.y += 0.25;
      sub.normalize();
      const s0 = mid.clone().addScaledVector(sub, -0.35);
      const s1 = mid.clone().addScaledVector(sub, 4 + rnd() * 4);
      cylSeg(s0, s1, r0 * 0.4, r0 * 0.15, barkDark, OUT * 0.65);
      plumeCanopy(s1, sub, 1.4 + rnd() * 0.8);
    }
  }

  // 顶冠两簇
  const top = trunkPts[trunkPts.length - 1];
  for (const side of [-1, 1]) {
    const elev = 0.72 + rnd() * 0.12;
    const yaw = side * (0.8 + rnd() * 0.5);
    const dir = new THREE.Vector3(
      Math.cos(yaw) * Math.cos(elev),
      Math.sin(elev),
      Math.sin(yaw) * Math.cos(elev)
    ).normalize();
    const start = top.clone().addScaledVector(dir, -0.5);
    const tip = top.clone().addScaledVector(dir, 6 + rnd() * 4);
    cylSeg(start, tip, R_TOP * 0.9, 0.2, barkDark, OUT * 0.7);
    plumeCanopy(tip, dir, 2.8 + rnd() * 1.2);
  }

  // 少量缠藤（保留月夜氛围，不抢有机骨架）
  const vineMat = toonMat(VINE_COLOR, { flatShading: true });
  const coils = 2 + ((rnd() * 2) | 0);
  for (let c = 0; c < coils; c++) {
    const y0 = 4 + rnd() * (h * 0.5);
    const len = 8 + rnd() * 12;
    const r = R_BOT * 0.7 + rnd() * 0.4;
    const pts = [];
    const seg = 12;
    for (let j = 0; j <= seg; j++) {
      const tt = j / seg;
      const yy = y0 + len * tt;
      const ang = tt * 2.2 * Math.PI + c * 1.9;
      pts.push(new THREE.Vector3(Math.cos(ang) * r, yy, Math.sin(ang) * r));
    }
    g.add(
      part(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.08, 4, false),
        vineMat,
        0.012
      )
    );
  }

  return g;
}

/* =====================================================================
 *  4d. 月夜氛围：树冠顶棚 / 巨叶垂吊 / 发光花蕊 / 粉色花蕊尖锥
 * ===================================================================== */
/** 树冠顶棚：三圈扁叶簇向内收拢 + 垂吊巨叶，交织遮天（水面不见阳光） */
function buildCanopyCeiling(rnd, swampZone) {
  const g = new THREE.Group();
  g.name = "swamp-canopy-ceiling";
  const blobMats = [CANOPY_DARK, CANOPY_MID, CANOPY_LIT].map((c) => toonMat(c, { flatShading: true }));
  // 树冠环：相对坑口地面高度 ×2（原 50/52/54 → 60/64/68）
  const rings = [
    { r: 27, y: leafHeightY(50), n: 11, s: 8.0 },
    { r: 17, y: leafHeightY(52), n: 8, s: 7.0 },
    { r: 7, y: leafHeightY(54), n: 5, s: 6.0 },
  ];
  for (const ring of rings) {
    for (let i = 0; i < ring.n; i++) {
      const a = (i / ring.n) * Math.PI * 2 + rnd() * 0.5;
      const blob = part(
        new THREE.IcosahedronGeometry(ring.s * (0.8 + rnd() * 0.5), 0),
        blobMats[(rnd() * 3) | 0],
        0.02
      );
      blob.scale.set(1.25, 0.6, 1.25); // 摊平成「冠」
      blob.position.set(
        Math.cos(a) * ring.r * (0.85 + rnd() * 0.3),
        ring.y + (rnd() - 0.5) * 3,
        Math.sin(a) * ring.r * (0.85 + rnd() * 0.3)
      );
      blob.rotation.y = rnd() * Math.PI;
      g.add(blob);
    }
  }
  // 巨叶垂吊：芭蕉式大叶自冠缘垂向坑心（参考图顶部大叶前景）
  const frondMats = [
    toonMat(0x16455a, { flatShading: true, side: THREE.DoubleSide }),
    toonMat(CANOPY_LIT, { flatShading: true, side: THREE.DoubleSide }),
  ];
  for (let i = 0; i < 12; i++) {
    const len = 7 + rnd() * 5;
    const frond = part(new THREE.PlaneGeometry(2.6 + rnd() * 2.2, len, 1, 3), frondMats[i % 2], 0.016);
    frond.geometry.translate(0, -len / 2, 0); // 顶边为悬挂轴
    const fp = frond.geometry.attributes.position;
    for (let k = 0; k < fp.count; k++) {
      const yy = -fp.getY(k); // 0..len 向下
      fp.setZ(k, fp.getZ(k) + yy * yy * 0.05); // 叶尖外弧
    }
    frond.geometry.computeVertexNormals();
    // 叶脉：沿叶面中轴与两侧放射的暗色细线（设计原稿要求宽大叶有清晰脉络）
    const veinMat = new THREE.LineBasicMaterial({ color: 0x0c2a33, transparent: true, opacity: 0.7 });
    const veinPts = [];
    const mid = len; // 主脉
    const vSeg = 6;
    for (let s = 0; s <= vSeg; s++) {
      const tt = s / vSeg;
      veinPts.push(new THREE.Vector3(0, -len * tt, len * len * tt * tt * 0.05));
    }
    const mainVein = new THREE.Line(new THREE.BufferGeometry().setFromPoints(veinPts), veinMat);
    mainVein.raycast = () => {};
    frond.add(mainVein);
    for (let s = 1; s <= 4; s++) {
      const tt = s / 5;
      const yY = -len * tt;
      const zZ = len * len * tt * tt * 0.05;
      for (const side of [-1, 1]) {
        const sideVein = new THREE.Line(
          new THREE.BufferGeometry().setFromPoints([
            new THREE.Vector3(0, yY, zZ),
            new THREE.Vector3(side * (1.0 + len * 0.12) * (1 - tt), yY - len * 0.12, zZ),
          ]),
          veinMat
        );
        sideVein.raycast = () => {};
        frond.add(sideVein);
      }
    }
    const a = rnd() * Math.PI * 2;
    const rr = 18 + rnd() * 14;
    // 巨叶悬挂点同步抬高到 2 倍离地高度
    frond.position.set(Math.cos(a) * rr, leafHeightY(45 + rnd() * 5), Math.sin(a) * rr);
    frond.rotation.order = "YXZ";
    frond.rotation.y = a + Math.PI / 2;
    frond.rotation.x = 0.55 + rnd() * 0.5; // 垂吊
    g.add(frond);
  }
  swampZone.add(g);
  return g;
}

/** 发光花蕊花：深色花瓣 + 明亮花蕊 + 加色光晕（月夜光源之二） */
function buildGlowFlower(rnd, hue) {
  const g = new THREE.Group();
  g.name = "swamp-glow-flower";
  const h = 0.5 + rnd() * 0.9;
  const stem = part(new THREE.CylinderGeometry(0.035, 0.05, h, 4), toonMat(0x1d5a5a, { flatShading: true }), 0.008);
  stem.position.y = h / 2;
  g.add(stem);
  const petalMat = toonMat(hue ? 0x2a7a80 : PETAL_DEEP, { flatShading: true, side: THREE.DoubleSide });
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const petal = part(new THREE.PlaneGeometry(0.16, 0.3), petalMat, 0.006);
    petal.position.set(Math.cos(a) * 0.12, h + 0.02, Math.sin(a) * 0.12);
    petal.rotation.order = "YXZ";
    petal.rotation.y = -a;
    petal.rotation.x = -0.9;
    g.add(petal);
  }
  const coreColor = hue ? STAMEN_MINT : STAMEN_PINK;
  const core = new THREE.Mesh(
    facet(new THREE.SphereGeometry(0.09 + rnd() * 0.05, 6, 5)),
    new THREE.MeshBasicMaterial({ color: coreColor, fog: false })
  );
  core.position.y = h + 0.06;
  g.add(core);
  const halo = glowSprite(coreColor, 1.5 + rnd() * 0.8, 0.55);
  halo.position.y = h + 0.06;
  halo.userData.pulse = rnd() * Math.PI * 2;
  g.add(halo);
  g.userData.halo = halo;
  return g;
}

/**
 * 巨型发光花朵：宽大花瓣朝空中开放，花蕊发光（设计原稿）。
 * 用于湖沼“5 朵大大花朵轮换飘落湖面”的效果。返回 group，含可动画的 userData。
 */
function buildGiantFlower(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-giant-flower";
  const petalMat = toonMat(0xf2d6e6, { flatShading: true, side: THREE.DoubleSide }); // 浅粉花瓣
  const petalN = 7;
  const pr = 2.4; // 花瓣半径（巨型）
  for (let i = 0; i < petalN; i++) {
    const a = (i / petalN) * Math.PI * 2;
    const petal = part(new THREE.PlaneGeometry(1.4, 2.6, 1, 2), petalMat, 0.02);
    petal.position.set(Math.cos(a) * pr, 0.2, Math.sin(a) * pr);
    petal.rotation.order = "YXZ";
    petal.rotation.y = -a;
    petal.rotation.x = -1.05; // 朝天空开放
    g.add(petal);
  }
  // 花蕊：发光球 + 加色光晕（如同设计原稿亮芯）
  const core = new THREE.Mesh(
    facet(new THREE.SphereGeometry(0.7, 8, 6)),
    new THREE.MeshBasicMaterial({ color: 0xfff0a0, fog: false })
  );
  core.position.y = 0.4;
  g.add(core);
  const halo = glowSprite(0xffe6a0, 7.0, 0.75, 'large-stamen');
  halo.position.y = 0.5;
  g.add(halo);
  g.userData.halo = halo;
  g.userData.core = core;
  return g;
}

/** 粉色发光花蕊尖锥：圆锥 + 亮尖 + 光晕（参考图叶舟中的粉锥） */
function buildStamenSpike(rnd) {
  const g = new THREE.Group();
  g.name = "swamp-stamen-spike";
  const spike = part(new THREE.ConeGeometry(0.42, 1.7, 6), toonMat(PINK_HANG, { flatShading: true }), 0.014);
  spike.position.y = 0.85;
  g.add(spike);
  const tip = new THREE.Mesh(
    facet(new THREE.SphereGeometry(0.12, 6, 5)),
    new THREE.MeshBasicMaterial({ color: STAMEN_PINK, fog: false })
  );
  tip.position.y = 1.72;
  g.add(tip);
  const halo = glowSprite(STAMEN_PINK, 2.2, 0.5);
  halo.position.y = 1.5;
  halo.userData.pulse = rnd() * Math.PI * 2;
  g.add(halo);
  g.userData.halo = halo;
  return g;
}

/* =====================================================================
 *  1. 主函数：地表向下深挖 30 单位大坑洞（水面降至地下 15 单位）
 * ===================================================================== */
/**
 * 创建莫比斯原初湖沼。
 * 局部 Y 轴锁死：Y=40 地表草地 / Y=25 玻璃水面 / Y=10 湖底沙地。
 * 玩家可从 Y=40 草地边缘自由落体，砸入 Y=25 水中。
 *
 * @param {{ seed?: number }} [opts]
 * @returns {THREE.Group & { userData: object, update?: Function }}
 */
export function createMoebiusSwampZone(opts = {}) {
  let s = (opts.seed ?? 20260804) >>> 0;
  const rnd = () => {
    s = (Math.imul(1664525, s) + 1013904223) >>> 0;
    return s / 0x100000000;
  };

  const swampZone = new THREE.Group();
  swampZone.name = "moebius-swamp-zone";

  /* ---------- 5. 月夜：不放置任何全局光源 ----------
   * 旧版纯白环境光 1.2 会照亮整个星球；现全沼改为不受光平涂材质，
   * 湖沼与昼夜循环彻底解耦（树冠遮挡阳光，仅萤火/花蕊作光源）。 */

  /* ---------- 坑洞外壳：上宽下窄的刀劈斧凿深渊碗壁 ---------- */
  // 坑壁：顶口 r≈34（Y=40）→ 底 r≈13（Y=10），内视碗壁
  const wallGeo = jitter(
    new THREE.CylinderGeometry(34, 13, SWAMP_LOCAL_GROUND_Y - SWAMP_FLOOR_Y, 14, 4, true),
    2.2,
    rnd
  );
  const wallFacet = facet(wallGeo);
  // 月夜坑壁：顶亮底暗的深蓝绿渐变 + 苔藓亮斑（顶点色，不受光）
  const wp = wallFacet.attributes.position;
  const wcol = new Float32Array(wp.count * 3);
  const cTop = new THREE.Color(0x24606c);
  const cBot = new THREE.Color(0x0c2a3a);
  const cMoss = new THREE.Color(WALL_MOSS);
  const cTmp = new THREE.Color();
  for (let i = 0; i < wp.count; i++) {
    const hgt = THREE.MathUtils.clamp((wp.getY(i) + 15) / 30, 0, 1);
    cTmp.copy(cBot).lerp(cTop, Math.pow(hgt, 1.35));
    const n = 0.5 + 0.5 * Math.sin(wp.getX(i) * 1.9 + wp.getZ(i) * 1.4) * Math.sin(wp.getY(i) * 0.8 + wp.getX(i) * 0.6);
    if (n > 0.72) cTmp.lerp(cMoss, Math.min(1, (n - 0.72) * 2.2));
    wcol[i * 3] = cTmp.r;
    wcol[i * 3 + 1] = cTmp.g;
    wcol[i * 3 + 2] = cTmp.b;
  }
  wallFacet.setAttribute("color", new THREE.BufferAttribute(wcol, 3));
  const wall = new THREE.Mesh(
    wallFacet,
    toonMat(0xffffff, { side: THREE.BackSide, vertexColors: true })
  );
  wall.name = "swamp-sinkhole-wall";
  wall.position.y = (SWAMP_LOCAL_GROUND_Y + SWAMP_FLOOR_Y) / 2; // 25
  wall.receiveShadow = true;
  addOutline(wall, 0.045);
  swampZone.add(wall);

  /* ---------- 坑口缘：自然塌陷断崖（无围墙！送信人可自由进出）---------- */
  const ENTRANCE_A = 0.5; // 入坑通道方位角（局部）
  const angDiff = (a) => Math.atan2(Math.sin(a - ENTRANCE_A), Math.cos(a - ENTRANCE_A));

  // 低矮断崖碎石（2026-08-29 主人验收：这组石头已整体迁往西芳寺苔庭，
  // 见 messengerIsland saihoji-scree-rocks；湖沼坑缘不再放置）。

  // 入口缓坡石阶：8 级宽石板从草地 Y=40 一路下行没入水下 Y≈22，可直接走入
  const walkSurfaces = [wall];
  const stepMat = toonMat(0x2f6a66, { flatShading: true });
  for (let i = 0; i < 8; i++) {
    const t = i / 7;
    const step = part(jitter(new THREE.BoxGeometry(8.5, 1.2, 3.2), 0.35, rnd), stepMat, 0.026);
    const rr = 37 - t * 12;
    step.position.set(
      Math.cos(ENTRANCE_A) * rr,
      SWAMP_LOCAL_GROUND_Y - 0.6 - t * 17.5,
      Math.sin(ENTRANCE_A) * rr
    );
    step.rotation.y = -ENTRANCE_A;
    step.rotation.x = 0.16; // 微微向坑心下倾
    swampZone.add(step);
    walkSurfaces.push(step);
  }

  swampZone.userData.tigerWalkSurfaces = walkSurfaces.slice(1);

  // 注：放置区「地表草地」已按需求移除——湖沼先挖坑，不展示坑口地面，
  // 坑缘只保留塌陷断崖碎石、入口石阶与环湖苍天大树，玩家自坑口直接踏入深渊。

  /* ---------- 坑边苍天大树：环湖沼四周，沿球面贴地扎根 ---------- */
  const treeCount = 10 + ((rnd() * 3) | 0);
  /** @type {THREE.Group[]} */
  const towerTrees = [];
  for (let i = 0; i < treeCount; i++) {
    const a = (i / treeCount) * Math.PI * 2 + rnd() * 0.35;
    if (Math.abs(angDiff(a)) < 0.5) continue; // 不堵入口通道
    const tree = buildToweringTree(rnd);
    // 注意：星球半径仅 40（局部有效半径 = 40/scale），坑缘平坦切平面在
    // 局部水平 ≈ Rs/√2 之外急剧下沉，树环必须收在坑缘附近才能贴地。
    const d = 36.5 + rnd() * 5;
    tree.position.set(Math.cos(a) * d, SWAMP_LOCAL_GROUND_Y - 0.3, Math.sin(a) * d);
    tree.userData.yaw = rnd() * Math.PI * 2; // 放置时贴球面后再绕法线自转
    swampZone.add(tree);
    towerTrees.push(tree);
  }
  // 星球是弯曲的：平坦切平面之外地表下沉，树/草皮需沿球面下探并朝法线生长，
  // 否则悬浮。缩放在放置时才确定，故由 applySwampSphereFit 统一修正。
  swampZone.userData.towerTrees = towerTrees;
  const rimDecor = (swampZone.userData.rimDecor = []); // 地表草地已移除，坑缘不再有草皮/草簇

  /* ---------- 相机距离外：树与树之间随机跨树蔓藤（丛林密网） ---------- */
  // 仅在大树两两之间按概率连一条悬垂的跨树藤蔓，营造密林缠绕感
  {
    const crossVineMat = toonMat(VINE_COLOR, { flatShading: true });
    const used = new Set();
    const tries = towerTrees.length * 2;
    for (let k = 0; k < tries; k++) {
      const i = (rnd() * towerTrees.length) | 0;
      let j = (rnd() * towerTrees.length) | 0;
      if (j === i) j = (j + 1) % towerTrees.length;
      const key = i < j ? `${i}-${j}` : `${j}-${i}`;
      if (used.has(key)) continue;
      used.add(key);
      if (rnd() > 0.55) continue; // 随机跳过部分组合
      const A = towerTrees[i].position;
      const B = towerTrees[j].position;
      const baseY = SWAMP_LOCAL_GROUND_Y - 0.3;
      const yA = baseY + 14 + rnd() * 18; // 相机距离外高处连接
      const yB = baseY + 14 + rnd() * 18;
      const sag = 4 + rnd() * 6; // 自然下垂
      const pts = [];
      const seg = 16;
      for (let s = 0; s <= seg; s++) {
        const tt = s / seg;
        const x = A.x + (B.x - A.x) * tt;
        const z = A.z + (B.z - A.z) * tt;
        const y = (yA + (yB - yA) * tt) - Math.sin(tt * Math.PI) * sag;
        pts.push(new THREE.Vector3(x, y, z));
      }
      const vine = part(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 32, 0.12 + rnd() * 0.05, 4, false),
        crossVineMat,
        0.014
      );
      vine.name = "swamp-cross-tree-vine";
      swampZone.add(vine);
    }
  }

  /* ---------- 5 朵巨型发光花朵：宽大叶上方朝空中开放，轮换飘落湖面 ---------- */
  const giantFlowers = [];
  for (let i = 0; i < 5; i++) {
    const f = buildGiantFlower(rnd);
    const a = (i / 5) * Math.PI * 2 + rnd() * 0.4;
    const d = 20 + rnd() * 10; // 宽大叶丛上方（坑缘棕榈带内侧）
    const baseY = SWAMP_LOCAL_GROUND_Y + 6 + rnd() * 8; // 在叶面之上朝天空开放
    f.position.set(Math.cos(a) * d, baseY, Math.sin(a) * d);
    f.userData.baseY = baseY;
    f.userData.fallOrder = i;        // 轮换次序
    f.userData.falling = false;      // 是否正在飘落
    f.userData.fallT = 0;            // 飘落计时
    f.userData.restT = 0;            // 湖面停留计时
    swampZone.add(f);
    giantFlowers.push(f);
  }
  swampZone.userData.giantFlowers = giantFlowers;

  /* ---------- 水面涟漪池：花朵触水时扩散 ---------- */
  const ripples = [];
  for (let i = 0; i < 12; i++) {
    const rp = createRipple();
    swampZone.add(rp);
    ripples.push(rp);
  }
  function spawnRipple(x, z, strength = 1) {
    const rp = ripples.find((r) => !r.userData.active);
    if (!rp) return;
    rp.userData.active = true;
    rp.userData.age = 0;
    rp.userData.life = 2.2 * strength;
    rp.position.set(x, WATER_Y + 0.07, z);
    rp.visible = true;
    rp.scale.setScalar(0.4);
    rp.material.opacity = 0.7 * strength;
  }
  function updateRipples(dt) {
    for (const rp of ripples) {
      if (!rp.userData.active) continue;
      rp.userData.age += dt;
      const k = rp.userData.age / rp.userData.life;
      if (k >= 1) {
        rp.userData.active = false;
        rp.visible = false;
        rp.material.opacity = 0;
        continue;
      }
      // 外扩（0.4 → 5.5）并淡出
      rp.scale.setScalar(0.4 + k * 5.1);
      rp.material.opacity = (1 - k) * 0.7;
    }
  }

  /* ---------- 落叶系统：参天大树落叶飘落，湖面漂浮落叶/花瓣 ---------- */
  const fallingLeaves = [];
  const LEAF_POOL = 60;
  for (let i = 0; i < LEAF_POOL; i++) {
    const leaf = createSwampLooseLeaf(0.6 + rnd() * 0.4, 0.32 + rnd() * 0.2);
    leaf.name = 'swamp-falling-leaf';
    leaf.visible = false;
    leaf.userData = { active: false };
    swampZone.add(leaf);
    fallingLeaves.push(leaf);
  }
  // 在湖面漂浮的落叶（静态漂浮物，强化“湖面”可读）
  for (let i = 0; i < 18; i++) {
    const a = rnd() * Math.PI * 2;
    const d = 3 + rnd() * 28;
    const fl = createSwampLooseLeaf(0.7 + rnd() * 0.5, 0.38 + rnd() * 0.25);
    fl.name = 'swamp-floating-leaf';
    fl.position.set(Math.cos(a) * d, WATER_Y + 0.08, Math.sin(a) * d);
    fl.rotation.set(-Math.PI / 2 + (rnd() - 0.5) * 0.2, rnd() * Math.PI, 0);
    fl.userData.drift = rnd() * Math.PI * 2;
    fl.userData.dRadius = d;
    swampZone.add(fl);
  }
  swampZone.userData.fallingLeaves = fallingLeaves;

  // 坑壁垂挂藤蔓（从 Y=40 坑口一路垂到水面附近）
  const hangVineMat = toonMat(VINE_COLOR, { flatShading: true });
  for (let i = 0; i < 8; i++) {
    const a = rnd() * Math.PI * 2;
    const y1 = WATER_Y + 2 + rnd() * 8;
    const pts = [];
    const rTop = 33, rBot = 26 - rnd() * 6;
    for (let j = 0; j <= 6; j++) {
      const t = j / 6;
      const rr = rTop + (rBot - rTop) * t;
      pts.push(new THREE.Vector3(
        Math.cos(a + t * 0.35) * rr,
        SWAMP_LOCAL_GROUND_Y - 1 + (y1 - (SWAMP_LOCAL_GROUND_Y - 1)) * t,
        Math.sin(a + t * 0.35) * rr
      ));
    }
    const vine = part(
      new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.14, 4, false),
      hangVineMat,
      0.015
    );
    swampZone.add(vine);
  }

  /* ---------- 树冠顶棚：苍天大树枝冠交织遮天（水面不见阳光） ---------- */
  // 树冠顶棚（2026-08-29 主人验收：深绿冠团在暮色里糊在苔庭视角，已去除）
  // buildCanopyCeiling(rnd, swampZone);

  /* ---------- 月光柱：树冠隙缝漏下几缕微弱冷光柱（「月夜」暗示） ---------- */
  const shafts = [];
  const shaftOpacityFactor = coralAtmosphereEnabled() ? .25 : 1;
  const shaftMat = new THREE.MeshBasicMaterial({
    color: MOON_SHAFT, transparent: true, opacity: 0.08 * shaftOpacityFactor,
    blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false,
  });
  for (let i = 0; i < 3; i++) {
    const a = ENTRANCE_A + (i - 1) * 2.1 + rnd() * 0.4;
    const d = 6 + rnd() * 10;
    const h = 30;
    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.5 + rnd() * 0.3, 2.0 + rnd() * 0.8, h, 8, 1, true),
      shaftMat
    );
    shaft.name = 'swamp-moon-shaft';
    shaft.position.set(Math.cos(a) * d, WATER_Y + h / 2 - 2, Math.sin(a) * d);
    shaft.rotation.z = (rnd() - 0.5) * 0.16;
    shaft.raycast = () => {};
    swampZone.add(shaft);
    shafts.push(shaft);
  }

  /* ---------- 萤火虫：水面与坑壁间漂移闪烁（月夜光源之一） ---------- */
  const fireflies = [];
  for (let i = 0; i < 46; i++) {
    const sp = buildCoralFirefly(i % 3 === 2 ? FIREFLY_B : FIREFLY_A, 0.5 + rnd() * 0.7);
    const a = rnd() * Math.PI * 2;
    const d = rnd() * 26;
    sp.position.set(Math.cos(a) * d, WATER_Y + 1 + rnd() * 12, Math.sin(a) * d);
    sp.userData.baseX = sp.position.x;
    sp.userData.baseY = sp.position.y;
    sp.userData.baseZ = sp.position.z;
    sp.userData.range = 1.5 + rnd() * 2.5;
    sp.userData.speed = 0.25 + rnd() * 0.4;
    sp.userData.flicker = 2 + rnd() * 3;
    sp.userData.phase = rnd() * Math.PI * 2;
    sp.userData.op = 0.5 + rnd() * 0.5;
    // 玩家入沼时的环绕/尾随参数
    sp.userData.followK = 0;
    sp.userData.orbitR = 1.4 + rnd() * 2.4;
    sp.userData.orbitH = 0.6 + rnd() * 2.2;
    sp.userData.orbitSpd = (0.8 + rnd() * 1.4) * (rnd() < 0.5 ? -1 : 1);
    sp.userData.orbitPh = rnd() * Math.PI * 2;
    sp.userData.trail = i % 3 === 0; // 1/3 尾随身后，其余环绕
    swampZone.add(sp);
    fireflies.push(sp);
  }
  // 光池：数个大而极淡的光晕，模拟萤群/花蕊光在水面的铺展
  const pools = [];
  for (let i = 0; i < 6; i++) {
    const pool = glowSprite(i % 2 ? 0x9fffd8 : 0xffc9dd, 7 + rnd() * 5, 0.07);
    const a = rnd() * Math.PI * 2;
    const d = 4 + rnd() * 18;
    pool.position.set(Math.cos(a) * d, WATER_Y + 1.5 + rnd() * 4, Math.sin(a) * d);
    pool.userData.phase = rnd() * Math.PI * 2;
    swampZone.add(pool);
    pools.push(pool);
  }

  /* ---------- 发光花蕊（月夜光源之二）：坑缘 / 壁架 / 水下 ---------- */
  const glowHalos = [];
  for (let i = 0; i < 8; i++) {
    const a = rnd() * Math.PI * 2;
    if (Math.abs(angDiff(a)) < 0.5) continue;
    const flower = buildGlowFlower(rnd, i % 2);
    const d = 34 + rnd() * 6;
    flower.position.set(Math.cos(a) * d, SWAMP_LOCAL_GROUND_Y - 0.1, Math.sin(a) * d);
    flower.userData.baseY = SWAMP_LOCAL_GROUND_Y - 0.1;
    swampZone.add(flower);
    rimDecor.push(flower);
    glowHalos.push(flower.userData.halo);
  }
  for (let i = 0; i < 6; i++) {
    const flower = buildGlowFlower(rnd, i % 2);
    const a = rnd() * Math.PI * 2;
    const d = 24 + rnd() * 7;
    flower.position.set(Math.cos(a) * d, WATER_Y + 1 + rnd() * 8, Math.sin(a) * d);
    flower.scale.setScalar(1.2 + rnd() * 0.8);
    swampZone.add(flower);
    glowHalos.push(flower.userData.halo);
  }
  for (let i = 0; i < 3; i++) {
    const flower = buildGlowFlower(rnd, 0);
    const a = rnd() * Math.PI * 2;
    const d = 6 + rnd() * 6;
    flower.position.set(Math.cos(a) * d, SWAMP_FLOOR_Y + 0.4, Math.sin(a) * d);
    swampZone.add(flower);
    glowHalos.push(flower.userData.halo);
  }

  /* ---------- 湖底：蓝色藻类地面（非草皮）+ 河床乱石 ---------- */
  // 坑底不是草皮，而是幽蓝发光的藻类植物铺地，强化“深邃湖水”的纵深感
  const ALGAE_COLOR = 0x1f6fb0;       // 湖底蓝藻主色
  const floor = part(
    jitter(new THREE.CylinderGeometry(13.5, 15, 1.2, 12), 0.8, rnd),
    toonMat(ALGAE_COLOR, { flatShading: true }),
    0.032
  );
  floor.name = "swamp-lake-floor";
  floor.position.y = SWAMP_FLOOR_Y - 0.2;
  swampZone.add(floor);
  walkSurfaces.push(floor);
  swampZone.userData.sampleGroundRadius = createSwampGroundSampler(swampZone, walkSurfaces);

  // 藻类簇：湖底散布的蓝绿发光藻团（高低起伏，营造水下植被层）
  const rootedAlgae = createSwampAlgaeClumps(rnd, swampZone, floor, SWAMP_FLOOR_Y);

  // 河床暗蓝乱石（置于藻类之间，不喧宾夺主）
  for (let i = 0; i < 14; i++) {
    const rock = part(
      new THREE.IcosahedronGeometry(0.5 + rnd() * 1.2, 0),
      toonMat(ROCK_COLOR, { flatShading: true }),
      0.02
    );
    const a = rnd() * Math.PI * 2;
    const d = 2 + rnd() * 10;
    rock.position.set(Math.cos(a) * d, SWAMP_FLOOR_Y + 0.4 + rnd() * 1.2, Math.sin(a) * d);
    rock.rotation.set(rnd(), rnd() * 2, rnd());
    rock.scale.set(1.15, 0.55 + rnd() * 0.4, 0.95);
    swampZone.add(rock);
  }

  /* ---------- 2. 玻璃水面（Y = 25.0）---------- */
  const water = createWaterSurface();
  swampZone.add(water);

  /* ---------- 2b. 水体体积剖面（Y = 10 → 25）：上浅蓝、下深蓝 ---------- */
  const waterVolume = createWaterVolume();
  swampZone.add(waterVolume);

  /* ---------- 水下游鱼：绿黑斑纹小鱼群（玻璃剖面下的生灵） ---------- */
  /** @type {THREE.Group[]} */
  const fishes = [];
  for (let i = 0; i < 9; i++) {
    const fish = buildCoralSmallFish(rnd, i);
    fish.position.set((rnd() - 0.5) * 30, 13 + rnd() * 9, (rnd() - 0.5) * 30);
    fish.userData.orbitR = 6 + rnd() * 12;
    fish.userData.orbitY = fish.position.y;
    fish.userData.phase = rnd() * Math.PI * 2;
    fish.userData.speed = 0.25 + rnd() * 0.3;
    swampZone.add(fish);
    fishes.push(fish);
  }

  /* ---------- 4a. 原始世界树（Y=10 扎根，穿水上天）---------- */
  buildWorldTree(rnd, swampZone);

  /* ---------- 3. 米白浅绿鲸豚：暂时游回湖心（离开喂食木筏） ---------- */
  /** @type {THREE.Group[]} */
  const whales = [];
  // 成鲸：湖心偏深一带缓慢绕游（不贴喂食筏）
  const whale = buildBelugaWhale(rnd);
  whale.position.set(-4, WHALE_Y - 0.6, -8);
  whale.rotation.order = "YXZ";
  whale.rotation.x = -1.05; // 略平，更像在游而非直立讨食
  whale.rotation.y = 2.4;
  whale.userData.baseY = WHALE_Y - 0.6;
  whale.userData.baseRotX = -1.05;
  whale.userData.bobPhase = 0.4;
  // 绕湖心椭圆巡游（本地 XZ）
  whale.userData.swim = {
    cx: 5,
    cz: -5,
    rx: 2.5,
    rz: 2,
    speed: 0.11,
    phase: 0.2,
    yawOffset: Math.PI * 0.5, // 切向朝向
  };
  swampZone.add(whale);
  whales.push(whale);

  // 幼鲸：跟随成鲸外侧稍浅处
  const whalePup = buildBelugaWhale(rnd);
  whalePup.scale.setScalar(0.55);
  whalePup.position.set(-10, WHALE_Y - 1.2, -3);
  whalePup.rotation.order = "YXZ";
  whalePup.rotation.x = -0.95;
  whalePup.rotation.y = 2.1;
  whalePup.userData.baseY = WHALE_Y - 1.2;
  whalePup.userData.baseRotX = -0.95;
  whalePup.userData.bobPhase = 2.1;
  whalePup.userData.swim = {
    cx: 5,
    cz: -5,
    rx: 3.4,
    rz: 2.8,
    speed: 0.13,
    phase: 1.8,
    yawOffset: Math.PI * 0.5,
  };
  swampZone.add(whalePup);
  whales.push(whalePup);

  /* ---------- 黑人孩子喂食白鲸：小木筏 + 举臂孩子 + 食物碎屑 ---------- */
  const feedRaft = createLotusLeafBoat(rnd, 2.3);
  feedRaft.position.set(10.2, WATER_Y + 0.1, 6.8);
  feedRaft.rotation.y = 0.2;
  feedRaft.userData.bobPhase = 1.3;
  feedRaft.userData.baseY = WATER_Y + 0.1;
  swampZone.add(feedRaft);
  if (feedRaft.userData.halo) glowHalos.push(feedRaft.userData.halo);

  // One of the same two boys feeds the whale; never add a third passenger.
  const feeder=feedRaft.userData.passengers[1];
  feeder.userData.storyRole='whale-feeder';feedRaft.userData.feeder=feeder;

  // 食物碎屑：手与鲸口之间的弧线上几点暖光
  const foodBits = [];
  const handW = new THREE.Vector3(9.1, 26.0, 5.8);
  const mouthW = new THREE.Vector3(7.6, 27.5, 4.5);
  for (let i = 0; i < 4; i++) {
    const k = 0.15 + i * 0.22;
    const bit = glowSprite(0xffe08a, 0.42, 0.85, 'signal');
    bit.position.lerpVectors(handW, mouthW, k);
    bit.position.y += Math.sin(k * Math.PI) * 0.5 + 0.6;
    bit.userData.phase = i * 1.7;
    swampZone.add(bit);
    foodBits.push(bit);
  }

  // 水下泅游的黑人孩子：玻璃水下的暗色剪影，绕鲸缓游
  const swimmer = buildNativeDoll(0.95);
  swimmer.rotation.order = "YXZ";
  swimmer.rotation.x = 1.35; // 俯身水平泅游
  swimmer.position.set(2.5, 20.8, 9.5);
  swampZone.add(swimmer);

  // 荷叶水下茎秆的锚点先记着（荷叶生成后补茎）
  /* ---------- 4b. 内凹荷叶小舟（Y = 25.0）3~4 朵 ---------- */
  /** @type {THREE.Group[]} */
  const lotuses = [feedRaft]; // 喂食木筏一并随水起伏
  const lotusSlots = [
    { x: -13, z: 9, r: 4.4, yaw: 0.4 },
    { x: 12, z: -12, r: 3.8, yaw: -0.9 },
    { x: -10, z: -14, r: 3.4, yaw: 1.6 },
    { x: 16, z: 10, r: 3.0, yaw: 2.4 },
  ];
  const lotusCount = 3 + ((rnd() * 2) | 0); // 3~4 朵
  for (let i = 0; i < lotusCount; i++) {
    const slot = lotusSlots[i];
    const lotus = createLotusLeafBoat(rnd, slot.r * (0.92 + rnd() * 0.16));
    lotus.position.set(slot.x, WATER_Y + 0.1, slot.z);
    lotus.rotation.y = slot.yaw + rnd() * 0.4;
    lotus.userData.bobPhase = rnd() * Math.PI * 2;
    lotus.userData.baseY = WATER_Y + 0.1;
    swampZone.add(lotus);
    lotuses.push(lotus);
    if (lotus.userData.halo) glowHalos.push(lotus.userData.halo);

    // 水下茎秆：从湖底 Y=10 一路连到荷叶
    const stemH = WATER_Y - SWAMP_FLOOR_Y;
    const stem = part(
      new THREE.CylinderGeometry(0.13, 0.2, stemH, 5),
      toonMat(0x1e8449, { flatShading: true }),
      0.014
    );
    stem.position.set(slot.x, SWAMP_FLOOR_Y + stemH * 0.5, slot.z);
    swampZone.add(stem);
    lotus.userData.flowerStem=stem;
    stem.userData.flowerStemAnchor=new THREE.Vector3(slot.x,SWAMP_FLOOR_Y,slot.z);
    stem.userData.flowerStemLength=stemH;
  }

  /* ---------- 氛围气泡 ---------- */
  const bubbles = [];
  for (let i = 0; i < 12; i++) {
    const bubble = new THREE.Mesh(
      new THREE.SphereGeometry(0.1 + rnd() * 0.09, 5, 4),
      new THREE.MeshBasicMaterial({
        color: 0x9fe8e0,
        transparent: true,
        opacity: 0.4,
        depthWrite: false,
      })
    );
    bubble.position.set((rnd() - 0.5) * 34, 12 + rnd() * 11, (rnd() - 0.5) * 34);
    bubble.userData.baseY = bubble.position.y;
    bubble.userData.phase = rnd() * Math.PI * 2;
    swampZone.add(bubble);
    bubbles.push(bubble);
  }

  /* ---------- 参考插画生态：鳗 / 管虫 / 紫蘑菇 / 粉垂生物 / 飞鸟 / 贝壳 / 棕榈 ---------- */
  // 黄绿鳗：水下 16~20 高度蛇形巡游
  const eel = buildSwampEel(rnd);
  eel.position.set(-2, 17.5, 0);
  swampZone.add(eel);

  // 橙红管状蠕虫：湖底两处
  for (let i = 0; i < 2; i++) {
    const worms = buildTubeWormCluster(rnd);
    const a = rnd() * Math.PI * 2;
    const d = 4 + rnd() * 6;
    worms.position.set(Math.cos(a) * d, SWAMP_FLOOR_Y + 0.4, Math.sin(a) * d);
    swampZone.add(worms);
  }

  // 紫蘑菇/珊瑚：坑缘草甸 + 水下岩隙
  for (let i = 0; i < 4; i++) {
    const mush = buildMoebiusMushroom(rnd, 1 + rnd() * 0.6);
    const a = rnd() * Math.PI * 2;
    if (Math.abs(angDiff(a)) < 0.55) continue;
    const d = 34.5 + rnd() * 4;
    mush.position.set(Math.cos(a) * d, SWAMP_LOCAL_GROUND_Y + 0.1, Math.sin(a) * d);
    mush.userData.baseY = SWAMP_LOCAL_GROUND_Y + 0.1;
    swampZone.add(mush);
    rimDecor.push(mush);
  }
  for (let i = 0; i < 2; i++) {
    const mush = buildMoebiusMushroom(rnd, 0.8 + rnd() * 0.5);
    const a = rnd() * Math.PI * 2;
    const d = 8 + rnd() * 4;
    mush.position.set(Math.cos(a) * d, SWAMP_FLOOR_Y + 0.35, Math.sin(a) * d);
    swampZone.add(mush);
  }

  // 粉色长尾垂挂生物：悬于坑壁藤蔓末端（3 只）
  /** @type {THREE.Group[]} */
  const hangers = [];
  for (let i = 0; i < 3; i++) {
    const hanger = buildPinkHanger(rnd);
    const a = (i / 3) * Math.PI * 2 + 0.9;
    const r = 28 + rnd() * 3;
    hanger.position.set(Math.cos(a) * r, SWAMP_LOCAL_GROUND_Y - 3 - rnd() * 5, Math.sin(a) * r);
    hanger.lookAt(0, hanger.position.y, 0);
    swampZone.add(hanger);
    hangers.push(hanger);
  }

  // 发光飞鸟：薄荷白 + 暖杏黄，枝头间来回穿梭（4 只）
  /** @type {THREE.Group[]} */
  const birds = [];
  for (let i = 0; i < 4; i++) {
    const bird = buildSwampBird(rnd, i % 2 ? GLOW_BIRD_A : GLOW_BIRD_B);
    bird.scale.setScalar(1.25); // 枝头发光鸟更醒目
    swampZone.add(bird);
    birds.push(bird);
    if (bird.userData.halo) glowHalos.push(bird.userData.halo);
  }

  // 长尾猴：树冠/垂叶间坐望→弧线跳跃（3 只）
  /** @type {THREE.Group[]} */
  const monkeys = [];
  for (let i = 0; i < 3; i++) {
    const mk = buildLongTailMonkey(rnd);
    mk.scale.setScalar(1.3);
    const perches = [];
    const n = 3 + ((rnd() * 2) | 0);
    for (let k = 0; k < n; k++) {
      const a = rnd() * Math.PI * 2;
      const d = 14 + rnd() * 14;
      perches.push(new THREE.Vector3(Math.cos(a) * d, 43 + rnd() * 6, Math.sin(a) * d));
    }
    mk.userData.perches = perches;
    mk.userData.idx = 0;
    mk.userData.next = 1 % n;
    mk.userData.sitDur = 1.4 + rnd() * 1.4;
    mk.userData.jumpDur = 0.7 + rnd() * 0.3;
    mk.userData.arc = 2.2 + rnd() * 1.6;
    mk.userData.phase = rnd() * 7;
    mk.userData.lastCi = Math.floor(mk.userData.phase / (mk.userData.sitDur + mk.userData.jumpDur));
    mk.userData.dodgeT = 0; // >0 时强制躲避跳
    mk.userData.dodgeFrom = new THREE.Vector3();
    mk.userData.dodgeTo = new THREE.Vector3();
    swampZone.add(mk);
    monkeys.push(mk);
  }

  // 投掷果实池（猴砸送信人 → 送信人接住回扔 → 猴躲避）
  const fruitGeo = facet(new THREE.SphereGeometry(0.17, 6, 5));
  const fruitMats = [
    toonMat(0xff9a4d, { flatShading: true }), // 橙果
    toonMat(0xe8708f, { flatShading: true }), // 浆果
  ];
  const fruits = [];
  for (let i = 0; i < 12; i++) {
    const fr = new THREE.Mesh(fruitGeo, fruitMats[i % 2]);
    fr.visible = false;
    fr.userData = {
      active: false,
      /** @type {'inbound'|'held'|'return'} */
      phase: "inbound",
      vel: new THREE.Vector3(),
      life: 0,
      holdT: 0,
      owner: null, // 投出的猴
      targetMk: null, // 回扔目标猴
    };
    swampZone.add(fr);
    fruits.push(fr);
  }
  /** @type {THREE.Mesh|null} 送信人手中暂存的果 */
  let heldFruit = null;

  // 飞刺池（主人 2026-09-05 湖沼生物袭击莫比斯机队）：蜥蜴喷光珠 / 飞鸟丢光羽，
  // 轻追踪飞向机队局部点，命中 → runtime.onFleetAttacked(射主) 触发开战
  const raidSpikes = [];
  for (let i = 0; i < 10; i++) {
    const sp = glowSprite(i % 2 ? 0x8fffc0 : 0xd8ffe0, 0.3, 0.95, 'signal');
    sp.visible = false;
    sp.userData = { active: false, vel: new THREE.Vector3(), life: 0, owner: null, targetObj: null };
    swampZone.add(sp);
    raidSpikes.push(sp);
  }

  // 发光蜥蜴：坑缘草甸缓爬 ×2 + 湖底 ×1
  /** @type {THREE.Group[]} */
  const lizards = [];
  for (let i = 0; i < 3; i++) {
    const lz = buildGlowLizard(rnd);
    lz.scale.setScalar(1.35);
    if (i < 2) {
      lz.userData.baseY = SWAMP_LOCAL_GROUND_Y + 0.12;
      lz.userData.orbitR = 33 + rnd() * 5;
    } else {
      lz.userData.baseY = SWAMP_FLOOR_Y + 0.3;
      lz.userData.orbitR = 8 + rnd() * 4;
    }
    lz.userData.speed = 0.1 + rnd() * 0.08;
    lz.position.y = lz.userData.baseY;
    swampZone.add(lz);
    lizards.push(lz);
    if (lz.userData.halo) glowHalos.push(lz.userData.halo);
  }

  // Keep authored orbit/RNG/raid data intact. Only ordinary lizards use this
  // rendered-ground route; the ship's water carrier retains its own animation.
  const coralLizardRoutesEnabled = new URLSearchParams(globalThis.location?.search || '').get('gregLakeRim') !== '0';
  let coralFloorGeometry=null, coralFloorRadius=0, coralFloorLocalTop=0;
  function updateGroundLizards(t) {
    const rim = coralLizardRoutesEnabled && swampZone.userData.gregCoralRim;
    for (let index = 0; index < lizards.length; index++) {
      const lz = lizards[index], u = lz.userData;
      const legacyAngle = t * u.speed + u.phase;
      let angle = legacyAngle, radius = u.orbitR + Math.sin(angle * 3.1) * 1.4, y = u.baseY;
      let heading = -angle + Math.sin(t * 2.2 + u.phase) * .25;
      if (rim?.ok) {
        if (!u.coralRoute) {
          const body=lz.getObjectByName('swamp-lizard-anatomy'),p=body.geometry.attributes.position;
          let footMin=Infinity,envelopeRadius=0;
          for(let i=0;i<p.count;i++){footMin=Math.min(footMin,p.getY(i)*lz.scale.y);envelopeRadius=Math.max(envelopeRadius,Math.hypot(p.getX(i)*lz.scale.x,p.getZ(i)*lz.scale.z));}
          u.coralRoute={kind:index<2?'rim-ping-pong':'floor-grounded',footMin,envelopeRadius,legacyOrbitR:u.orbitR,legacyBaseY:u.baseY};
        }
        const route=u.coralRoute;
        if(index<2){
          const patrolRadius=rim.rimPatrolRadius||37.4;
          const clearance=Math.asin((route.envelopeRadius+.16)/(patrolRadius-.1));
          const start=rim.entranceAngle+rim.entranceHalfAngle+clearance;
          const span=Math.PI*2-2*(rim.entranceHalfAngle+clearance);
          const phase=t*u.speed*.35+u.phase;
          angle=start+span*(.5+.5*Math.sin(phase));
          radius=patrolRadius+.1*Math.sin(phase*2);
          const da=span*.5*Math.cos(phase),dr=.2*Math.cos(phase*2);
          heading=Math.atan2(dr*Math.cos(angle)-radius*Math.sin(angle)*da,dr*Math.sin(angle)+radius*Math.cos(angle)*da);
          y=rim.topY-route.footMin;
          Object.assign(route,{radius:patrolRadius,radialAmplitude:.1,startAngle:start,endAngle:start+span,topY:rim.topY,entranceClearance:clearance});
        }else{
          if(coralFloorGeometry!==floor.geometry){
            floor.geometry.computeBoundingBox();coralFloorLocalTop=floor.geometry.boundingBox.max.y;
            const positions=floor.geometry.attributes.position;let topRadius=0;
            for(let i=0;i<positions.count;i++)if(Math.abs(positions.getY(i)-coralFloorLocalTop)<1e-4)topRadius=Math.max(topRadius,Math.hypot(positions.getX(i),positions.getZ(i)));
            coralFloorRadius=topRadius*Math.cos(Math.PI/(floor.geometry.parameters?.radialSegments||48));coralFloorGeometry=floor.geometry;
          }
          const maxRadius=coralFloorRadius*Math.min(floor.scale.x,floor.scale.z)-route.envelopeRadius-.05;
          radius=Math.min(radius,maxRadius);
          const topY=floor.position.y+coralFloorLocalTop*floor.scale.y;
          y=topY-route.footMin;Object.assign(route,{topY,maxRadius});
        }
      }
      lz.position.set(Math.cos(angle)*radius,y,Math.sin(angle)*radius);
      lz.rotation.y=heading;
    }
  }

  // 发光带鱼：水下摆尾环游（3 条）
  /** @type {THREE.Group[]} */
  const ribbons = [];
  for (let i = 0; i < 3; i++) {
    const rf = buildRibbonFish(rnd);
    rf.userData.orbitR = 7 + rnd() * 9;
    rf.userData.orbitY = 15 + rnd() * 6;
    rf.userData.speed = 0.16 + rnd() * 0.12;
    rf.userData.wave = 5 + rnd() * 3;
    swampZone.add(rf);
    ribbons.push(rf);
    if (rf.userData.halo) glowHalos.push(rf.userData.halo);
  }

  /* ---------- 战船维修厂：长尾猴换桅杆 / 蜥蜴送水 / 白鲸陪伴战船驶出湖沼 ---------- */
  // 船A：进坞维修的战船（桅杆帆索已拆下待换），长尾猴负责吊装备用桅
  const shipA = createFisherBoat({crewStyle:'swamp-coral'});
  shipA.name = "swamp-warship-repair";
  // 正式页的全球海壳会完整盖住这艘谷底维修船；允许装配器在确认
  // 整船（含描边）都在水下后关闭该子树。独立湖沼场景不受此标记影响。
  shipA.userData.officialOceanOcclusionCandidate = true;
  shipA.scale.setScalar(2); // 战船整体放大一倍（剪纸桨手/维修工位随船同步）
  for (const child of [...shipA.children]) {
    // 桅杆/帆/横桁/支索/旗组 = 中线高位件，拆除待修（露出无桅战船）
    if (child.position.y > 1.1) child.visible = false;
  }
  const angA = 2.05;
  const rA = 14;
  shipA.position.set(Math.cos(angA) * rA, WATER_Y + 0.02, Math.sin(angA) * rA);
  shipA.rotation.y = Math.atan2(Math.sin(angA), -Math.cos(angA)); // 船头朝湖心
  swampZone.add(shipA);

  // 备用桅：枢轴立于甲板桅座，平躺 → 被长尾猴立起就位（周而复始的换桅作业）
  const MAST_LEN = 3.4;
  const yardWood = toonMat(0x7a6248, { flatShading: true });
  const mastPivot = new THREE.Group();
  mastPivot.position.set(0.55, 0.66, 0.3);
  mastPivot.rotation.z = Math.PI / 2; // 沿甲板平躺朝船尾
  shipA.add(mastPivot);
  const spareMast = part(new THREE.CylinderGeometry(0.05, 0.07, MAST_LEN, 7), yardWood, 0.024);
  spareMast.position.y = MAST_LEN * 0.5;
  mastPivot.add(spareMast);
  const spareYard = part(new THREE.CylinderGeometry(0.035, 0.035, 2.3, 6), yardWood, 0.018);
  spareYard.rotation.x = Math.PI / 2;
  spareYard.position.y = MAST_LEN * 0.82;
  mastPivot.add(spareYard);

  // 吊装三脚架：三根斜撑聚于桅座上方 + 顶点暖灯（月夜维修工位的标志）
  const poleMat = toonMat(0x5a4632, { flatShading: true });
  for (let i = 0; i < 3; i++) {
    const pa = Math.PI / 2 + (i * Math.PI * 2) / 3;
    const bx = 0.55 + Math.cos(pa) * 0.58;
    const bz = Math.sin(pa) * 0.58;
    const pole = part(new THREE.CylinderGeometry(0.045, 0.06, Math.hypot(0.58, 4.06), 5), poleMat, 0.014);
    pole.position.set((bx + 0.55) / 2, (0.62 + 4.72) / 2, bz / 2);
    pole.lookAt(0.55, 4.72, 0);
    pole.rotateX(Math.PI / 2);
    shipA.add(pole);
  }
  const dockLantern = glowSprite(0xffd98a, 1.6, 0.8);
  dockLantern.position.set(0.55, 4.8, 0);
  shipA.add(dockLantern);
  glowHalos.push(dockLantern);

  // 两只工猴：甲板推举者 + 骑桅顶挂钩者（随桅杆起落，立起时挥手）
  const mkLift = buildLongTailMonkey(rnd, {tailPose:'deck'});
  mkLift.scale.setScalar(0.5);
  mkLift.position.set(-0.2, 0.66, 0.34);
  mkLift.rotation.y = Math.PI / 2; // 面向桅杆
  shipA.add(mkLift);
  const mkTop = buildLongTailMonkey(rnd, {tailPose:'deck',tailRise:true});
  mkTop.scale.setScalar(0.46);
  mkTop.position.set(0.14, MAST_LEN * 0.62, 0.1);
  mkTop.rotation.y = Math.PI * 0.3;
  mastPivot.add(mkTop);

  // 送水蜥蜴：沿甲板右舷走道巡游，水珠弧抛向两列剪纸士兵的头
  const waterLizard = buildGlowLizard(rnd);
  waterLizard.scale.setScalar(0.42);
  waterLizard.position.set(-1.2, 0.66, 0.28);
  shipA.add(waterLizard);
  if (waterLizard.userData.halo) glowHalos.push(waterLizard.userData.halo);
  const gourd = part(new THREE.SphereGeometry(0.09, 5, 4), toonMat(0x3f7fa8, { flatShading: true }), 0.006);
  gourd.position.set(0, 0.3, -0.16); // 背上的水葫芦
  waterLizard.add(gourd);
  const waterDrops = [];
  for (let i = 0; i < 5; i++) {
    const drop = glowSprite(0xa8e8ff, 0.22, 0.9, 'signal');
    drop.visible = false;
    drop.userData.seed = i;
    drop.userData.deliveryTarget = new THREE.Vector3();
    shipA.add(drop);
    waterDrops.push(drop);
  }

  // 维修浮台：木质筏排泊在船侧 + 备用圆木/水桶；水面另漂两根备用桁杆
  const fwdA = new THREE.Vector3(Math.cos(shipA.rotation.y), 0, -Math.sin(shipA.rotation.y));
  const rightA = new THREE.Vector3(-fwdA.z, 0, fwdA.x);
  const barge = new THREE.Group();
  barge.name = "swamp-repair-barge";
  barge.position.copy(shipA.position).addScaledVector(rightA, 1.9);
  barge.position.y = WATER_Y + 0.1;
  barge.rotation.y = shipA.rotation.y;
  swampZone.add(barge);
  const plankMat = toonMat(0x8a6f4d, { flatShading: true });
  for (let i = 0; i < 3; i++) {
    const plank = part(new THREE.BoxGeometry(4.8, 0.14, 0.55), plankMat, 0.02);
    plank.position.set(0, 0, (i - 1) * 0.58);
    barge.add(plank);
  }
  const spareLog = part(new THREE.CylinderGeometry(0.09, 0.11, 3.4, 6), yardWood, 0.016);
  spareLog.rotation.z = Math.PI / 2;
  spareLog.position.set(-0.4, 0.18, -0.42);
  barge.add(spareLog);
  const barrel = part(new THREE.CylinderGeometry(0.24, 0.2, 0.5, 7), poleMat, 0.014);
  barrel.position.set(1.6, 0.32, 0.3);
  barge.add(barrel);
  /** @type {THREE.Mesh[]} */
  const spars = [];
  for (let i = 0; i < 2; i++) {
    const spar = part(new THREE.CylinderGeometry(0.07, 0.09, 2.6, 5), yardWood, 0.014);
    spar.rotation.z = Math.PI / 2;
    spar.rotation.y = 0.6 + i * 1.7;
    const sa = angA + 0.34 + i * 0.22;
    spar.position.set(Math.cos(sa) * (rA + 2.2), WATER_Y + 0.05, Math.sin(sa) * (rA + 2.2));
    spar.userData.bobPhase = i * 2.1;
    swampZone.add(spar);
    spars.push(spar);
  }

  // 船B：修毕待发的战船 —— 泊稳 → 划桨驶向入口豁口 → 爬上石阶出沼（循环）
  const shipB = createFisherBoat({crewStyle:'swamp-coral'});
  shipB.name = "swamp-warship-depart";
  // 同上：只有正式页海壳的实际包围检测通过才会关闭，不能按位置硬删。
  shipB.userData.officialOceanOcclusionCandidate = true;
  installSwampWarshipRowing(shipA,swampZone);
  installSwampWarshipRowing(shipB,swampZone);
  shipB.userData.swampLakeVoyage={phase:"dock",cycle:0,closedWaterRoute:true};
  const SHIPB_SCALE = 2; // 战船整体放大一倍
  swampZone.add(shipB);
  // Wake remains driven by updateWarshipOars.

  // 护送白鲸：泊位绕游 / 并游护航 / 出口破水领航后潜回
  const escortWhale = buildBelugaWhale(rnd);
  escortWhale.scale.setScalar(0.5);
  escortWhale.rotation.order = "YXZ";
  swampZone.add(escortWhale);

  swampZone.userData.shipyard = {
    dock: shipA,
    barge,
    mastPivot,
    workers: [mkLift, mkTop],
    waterLizard,
    departure: shipB,
    escort: escortWhale,
  };

  /* ---------- 赛博水墨虎：大树间巡游 + 沿石阶下坑饮水 ---------- */
  const tigerRim = [0.5, 1.6, 2.7, 3.9, 5.1].map(
    (a) => new THREE.Vector3(Math.cos(a) * 37.4, SWAMP_LOCAL_GROUND_Y, Math.sin(a) * 37.4)
  );
  const tigerSteps = [0.15, 0.4, 0.65, 0.9].map((tt) =>
    new THREE.Vector3(
      Math.cos(ENTRANCE_A) * (37 - 12 * tt),
      SWAMP_LOCAL_GROUND_Y - 17.5 * tt,
      Math.sin(ENTRANCE_A) * (37 - 12 * tt)
    )
  );
  const tiger = createMoebiusTiger(rnd, {
    rim: tigerRim,
    steps: tigerSteps,
    drink: tigerSteps[3],
    speed: 2.6,
  }, { anatomy: opts.tigerAnatomy });
  swampZone.add(tiger);
  swampZone.userData.tiger = tiger;

  // 米白贝壳：坑缘草甸散落（3 枚，与苔石相伴）
  for (let i = 0; i < 3; i++) {
    const shell = buildShell(rnd);
    const a = rnd() * Math.PI * 2;
    const d = 34 + rnd() * 6;
    shell.position.set(Math.cos(a) * d, SWAMP_LOCAL_GROUND_Y + 0.15, Math.sin(a) * d);
    shell.rotation.y = rnd() * Math.PI * 2;
    shell.userData.baseY = SWAMP_LOCAL_GROUND_Y + 0.15;
    swampZone.add(shell);
    rimDecor.push(shell);
  }

  // 坑缘棕榈：与苍天巨树交错，湿润繁茂的丛林感（同样贴球面）
  for (let i = 0; i < 5; i++) {
    const a = rnd() * Math.PI * 2;
    if (Math.abs(angDiff(a)) < 0.5) continue;
    const palm = buildRimPalm(rnd);
    const d = 36 + rnd() * 4.5;
    palm.position.set(Math.cos(a) * d, SWAMP_LOCAL_GROUND_Y - 0.2, Math.sin(a) * d);
    palm.userData.yaw = rnd() * Math.PI * 2;
    swampZone.add(palm);
    towerTrees.push(palm); // 一并交给 applySwampSphereFit 贴球面
  }

  /* ---------- userData / 实时动画 ---------- */
  swampZone.userData.kind = "moebius-swamp";
  swampZone.userData.groundY = SWAMP_LOCAL_GROUND_Y;
  swampZone.userData.waterY = WATER_Y;
  swampZone.userData.floorY = SWAMP_FLOOR_Y;
  swampZone.userData.whale = whale;
  swampZone.userData.whales = whales;
  swampZone.userData.lotuses = lotuses;
  swampZone.userData.nectarTargets = [];
  // 不设大型碰撞体：送信人可直接走入 / 跳入湖沼（无隐形围墙）
  swampZone.userData.collideRadius = 0;
  swampZone.userData.cameraHint = {
    // 月夜：机位入坑内仰俯树冠/水面
    localPosition: new THREE.Vector3(17, 31.5, 19),
    localLookAt: new THREE.Vector3(0, 29, 0),
    fov: 62,
  };

  swampZone.update = function updateSwamp(_dt, t, runtime) {
    const onFleetHit = typeof runtime?.onFleetAttacked === "function"
      ? runtime.onFleetAttacked : null;

    /* ---------- 湖沼生物袭击莫比斯机队（主人 2026-09-05）---------- */
    // runtime.fleetObjects：世界坐标机队对象清单（莫比斯 aircraft + 泡机 + 运输艇）；
    // runtime.onFleetAttacked：命中回调 → vanguardAssault 记威胁 + 触发全员开战。
    // 长尾猴扔果 / 发光蜥蜴喷光珠 / 发光飞鸟丢光羽，轻追踪咬住飞行中的机队。
    const fleetObjs = runtime?.fleetObjects;
    if (fleetObjs?.length && onFleetHit) {
      swampZone.updateWorldMatrix(true, false);
      const fleetPts = [];  // 机队局部坐标缓存
      const fleetRef = [];  // 与 fleetPts 索引对齐的机队对象
      for (const o of fleetObjs) {
        if (!o?.parent) continue;
        o.getWorldPosition(_raidV1);
        swampZone.worldToLocal(_raidV1);
        fleetPts.push(_raidV1.clone());
        fleetRef.push(o);
      }
      if (fleetPts.length) {
        const RAID_RANGE2 = 110 * 110; // 局部 110（scale 0.5 → 世界 ~55m）
        const nearestFleet = (from) => {
          let bi = -1;
          let bd = Infinity;
          for (let i = 0; i < fleetPts.length; i++) {
            const d = from.distanceToSquared(fleetPts[i]);
            if (d < bd) { bd = d; bi = i; }
          }
          return bd <= RAID_RANGE2 ? bi : -1;
        };
        const takeSpike = () => raidSpikes.find((x) => !x.userData.active) || null;
        // 发光蜥蜴：坑缘抬头喷光珠
        for (const lz of lizards) {
          const u = lz.userData;
          u.raidCd = (u.raidCd || 0) - _dt;
          if (u.raidCd > 0) continue;
          const bi = nearestFleet(lz.position);
          if (bi < 0) continue;
          const sp = takeSpike();
          if (!sp) continue;
          u.raidCd = 5 + Math.random() * 4;
          sp.visible = true;
          sp.position.copy(lz.position);
          sp.position.y += 0.4;
          const su = sp.userData;
          su.active = true; su.owner = lz; su.targetObj = fleetRef[bi]; su.life = 8;
          su.vel.copy(fleetPts[bi]).sub(sp.position).normalize().multiplyScalar(22);
        }
        // 发光飞鸟：穿梭间朝机队丢光羽
        for (const bd of birds) {
          const u = bd.userData;
          u.raidCd = (u.raidCd || 0) - _dt;
          if (u.raidCd > 0) continue;
          const bi = nearestFleet(bd.position);
          if (bi < 0) continue;
          const sp = takeSpike();
          if (!sp) continue;
          u.raidCd = 7 + Math.random() * 5;
          sp.visible = true;
          sp.position.copy(bd.position);
          const su = sp.userData;
          su.active = true; su.owner = bd; su.targetObj = fleetRef[bi]; su.life = 8;
          su.vel.copy(fleetPts[bi]).sub(sp.position).normalize().multiplyScalar(20);
        }
        // 长尾猴：树冠上朝机队扔果（复用果实池，phase "raid"，命中在果循环结算）
        for (const mk of monkeys) {
          const u = mk.userData;
          u.raidCd = (u.raidCd || 0) - _dt;
          if (u.raidCd > 0) continue;
          const bi = nearestFleet(mk.position);
          if (bi < 0) continue;
          const fr = fruits.find((x) => !x.userData.active);
          if (!fr) continue;
          u.raidCd = 6 + Math.random() * 5;
          const fu = fr.userData;
          fu.active = true;
          fu.phase = "raid";
          fu.owner = null;
          fu.targetMk = null;
          fu.raidOwner = mk; // 谁扔的：命中回调记进优先打击名单
          fu.raidTargetObj = fleetRef[bi];
          fu.life = 8;
          fr.visible = true;
          fr.position.copy(mk.position);
          fr.position.y += 0.9;
          fu.vel.copy(fleetPts[bi]).sub(fr.position).normalize().multiplyScalar(19);
        }
        // 飞刺推进 + 命中结算（蜥蜴光珠 / 鸟光羽）
        for (const sp of raidSpikes) {
          const su = sp.userData;
          if (!su.active) continue;
          su.life -= _dt;
          let hit = false;
          if (su.targetObj?.parent) {
            su.targetObj.getWorldPosition(_raidV1);
            swampZone.worldToLocal(_raidV1);
            _raidV2.copy(_raidV1).sub(sp.position);
            const d = _raidV2.length();
            if (d < 2.0) hit = true;
            else {
              _raidV2.normalize().multiplyScalar(su.vel.length() || 20);
              su.vel.lerp(_raidV2, Math.min(1, _dt * 2.5)); // 轻追踪咬住机队
            }
          }
          if (hit || su.life <= 0) {
            if (hit) onFleetHit(su.owner);
            su.active = false;
            sp.visible = false;
            continue;
          }
          sp.position.addScaledVector(su.vel, _dt);
        }
      }
    }

    /* ---------- 玩家入沼判定：萤火环绕/尾随 + 长尾猴投果 ---------- */
    const player = runtime?.player;
    let playerIn = false;
    if (player) {
      swampZone.updateWorldMatrix(true, false);
      _ffP.copy(player.position);
      swampZone.worldToLocal(_ffP);
      const horiz = Math.hypot(_ffP.x, _ffP.z);
      playerIn = horiz < 30 && _ffP.y > 12 && _ffP.y < 52;
      swampZone.getWorldQuaternion(_ffQ).invert();
      _ffF.copy(player.facing).applyQuaternion(_ffQ);
      _ffF.y = 0;
      if (_ffF.lengthSq() < 1e-6) _ffF.set(0, 0, 1);
      _ffF.normalize();
    }
    // 荷叶小舟随水起伏
    for (const lotus of lotuses) {
      const ph = lotus.userData.bobPhase || 0;
      lotus.position.y = (lotus.userData.baseY || WATER_Y) + Math.sin(t * 1.05 + ph) * 0.09;
      lotus.rotation.z = Math.sin(t * 0.8 + ph) * 0.028;
      for(const boy of lotus.userData.passengers||[])boy.userData.updateFlowerBoy?.(t+ph);
    }
    // 鲸豚：暂时游回湖心椭圆巡游（离开喂食筏）+ 轻柔浮沉换气
    for (const w of whales) {
      const ph = w.userData.bobPhase || 0;
      const sw = w.userData.swim;
      if (sw) {
        const ang = sw.phase + t * sw.speed;
        const x = sw.cx + Math.cos(ang) * sw.rx;
        const z = sw.cz + Math.sin(ang) * sw.rz;
        w.position.x = x;
        w.position.z = z;
        // 切向朝向（沿轨道前进）
        const tx = -Math.sin(ang) * sw.rx;
        const tz = Math.cos(ang) * sw.rz;
        // The continuous beluga loft's nose is +Z. atan2(tx,tz) already
        // points it along the real path tangent; the old extra quarter-turn
        // made it travel sideways.
        w.rotation.y = Math.atan2(tx, tz);
      }
      w.position.y = (w.userData.baseY ?? WHALE_Y) + Math.sin(t * 0.55 + ph) * 0.4;
      const breathe = Math.sin(t * 0.28 + ph);
      const baseRx = w.userData.baseRotX ?? -1.05;
      // 换气时略抬头，幅度比贴筏讨食时小
      w.rotation.x = baseRx + breathe * 0.28;
      w.rotation.z = Math.sin(t * 0.4 + ph) * 0.04;
    }

    swampZone.userData.flowerBoyActivities?.update(t);

    /* ---------- 5 朵巨型发光花朵：轮换飘落湖面（花蕊发光） ---------- */
    const giantFlowers = swampZone.userData.giantFlowers || [];
    for (let i = 0; i < giantFlowers.length; i++) {
      const f = giantFlowers[i];
      const cyc = (t * 0.05 + i * 0.37) % 1; // 每朵独立相位，轮换有一朵在飘落
      // 花蕊发光脉动
      if (f.userData.core) {
        const pulse = 0.7 + Math.sin(t * 1.6 + i) * 0.3;
        f.userData.core.material.color.setRGB(pulse, pulse * 0.92, 0.55);
      }
      // 被 aircraft 扫描激光吸入中：跳过本花位置逻辑，避免抢位移
      if (f.userData.scanSucking) {
        f.userData.restT = Math.min(f.userData.restT ?? 0, 1);
        continue;
      }
      if (!f.userData.falling) {
        // 正常开放：在叶面之上朝天空轻微摇曳（非水面蜜源）
        f.userData.onWater = false;
        f.userData.feeding = false;
        f.position.y = f.userData.baseY + Math.sin(t * 0.5 + i) * 0.3;
        f.rotation.y += _dt * 0.05;
        // 触发飘落：每朵按各自周期落下一次
        if (cyc > 0.82) {
          f.userData.falling = true;
          f.userData.fallT = 0;
          f.userData.restT = 0;
          f.userData.splashed = false;
        }
      } else {
        // 飘落：从叶面高度缓慢下落至湖面（旋转飘摆）
        f.userData.fallT += _dt;
        const k = Math.min(1, f.userData.fallT / 6.0); // 6 秒落至水面
        const startY = f.userData.baseY;
        const targetY = WATER_Y + 0.3;
        f.position.y = startY + (targetY - startY) * k;
        f.rotation.x += _dt * 0.4;
        f.rotation.z += _dt * 0.3;
        if (k >= 1) {
          // 首次触水 → 在落点激起涟漪；可供 aircraft 蜂鸟吸食
          if (!f.userData.splashed) {
            f.userData.splashed = true;
            f.userData.onWater = true;
            f.userData.nectar = 1; // 1=满蜜，被吸食后衰减
            f.userData.restT = 0;
            spawnRipple(f.position.x, f.position.z, 1.3);
          }
          // 落湖面后停留；被吸食时花蕊更亮、蜜量衰减
          f.userData.restT += _dt;
          if (f.userData.feeding && f.userData.core) {
            const p2 = 0.85 + Math.sin(t * 8 + i) * 0.15;
            f.userData.core.material.color.setRGB(p2, p2 * 0.5, 0.9);
            f.userData.nectar = Math.max(0, (f.userData.nectar ?? 1) - _dt * 0.22);
          }
          // 蜜尽或停留超时 → 复位重新开放
          // 水面停留稍长，给空中「巨蜂鸟」编队赶路吸蜜的时间
          const restLimit = f.userData.feeding ? 16.0 : 14.0;
          if (f.userData.restT > restLimit || (f.userData.nectar ?? 0) <= 0.05) {
            f.userData.falling = false;
            f.userData.splashed = false;
            f.userData.onWater = false;
            f.userData.feeding = false;
            f.userData.nectar = 0;
            f.userData.restT = 0;
            f.rotation.set(0, f.rotation.y, 0);
            f.position.y = f.userData.baseY;
          }
        }
      }
    }

    // 暴露蜜源（世界坐标）供 aircraft 寻觅吸食
    {
      const nectar = [];
      const _nw = new THREE.Vector3();
      for (const f of giantFlowers) {
        if (f.userData.onWater && (f.userData.nectar ?? 0) > 0.08) {
          f.getWorldPosition(_nw);
          nectar.push({
            flower: f,
            worldPos: _nw.clone(),
            nectar: f.userData.nectar ?? 1,
          });
        }
      }
      swampZone.userData.nectarTargets = nectar;
      // placement 包装也挂一份
      if (swampZone.parent?.userData?.kind === "moebius-swamp") {
        swampZone.parent.userData.nectarTargets = nectar;
      }
    }

    // 水面涟漪扩散淡出
    updateRipples(_dt);

    /* ---------- 落叶系统：参天大树落叶飘落 + 湖面漂浮落叶 ---------- */
    const fallingLeaves = swampZone.userData.fallingLeaves || [];
    // 周期性从随机大树顶部生成落叶
    if (Math.random() < _dt * 6) {
      const free = fallingLeaves.find((l) => !l.userData.active);
      if (free && towerTrees.length) {
        const src = towerTrees[(Math.random() * towerTrees.length) | 0];
        free.position.copy(src.position);
        // 树冠已抬高 2 倍：从冠顶附近飘落
        free.position.y += (30 + Math.random() * 20) * LEAF_HEIGHT_MUL;
        free.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
        free.userData.active = true;
        free.userData.vy = -(1.2 + Math.random() * 1.2);
        free.userData.spin = (Math.random() - 0.5) * 2;
        free.userData.sway = Math.random() * Math.PI * 2;
        free.visible = true;
      }
    }
    for (const l of fallingLeaves) {
      if (!l.userData.active) continue;
      l.userData.sway += _dt * 2;
      l.position.y += l.userData.vy * _dt;
      l.position.x += Math.sin(l.userData.sway) * _dt * 0.6;
      l.position.z += Math.cos(l.userData.sway) * _dt * 0.6;
      l.rotation.x += l.userData.spin * _dt;
      l.rotation.z += l.userData.spin * 0.7 * _dt;
      if (l.position.y <= WATER_Y + 0.1) {
        // 落到水面：转为漂浮（停在水面，缓慢漂）
        l.position.y = WATER_Y + 0.1;
        l.userData.active = false;
        l.rotation.set(-Math.PI / 2 + (Math.random() - 0.5) * 0.2, Math.random() * Math.PI, 0);
        l.userData.drift = Math.random() * Math.PI * 2;
        l.userData.dRadius = Math.hypot(l.position.x, l.position.z) || 5;
      }
    }
    // 湖面漂浮落叶缓慢旋转漂移
    for (const l of swampZone.children) {
      if (l.userData && l.userData.drift !== undefined) {
        l.userData.drift += _dt * 0.15;
        const r = l.userData.dRadius;
        l.position.x = Math.cos(l.userData.drift) * r + Math.sin(t + l.userData.drift) * 0.3;
        l.position.z = Math.sin(l.userData.drift) * r + Math.cos(t + l.userData.drift) * 0.3;
      }
    }
    // 游鱼环游
    for (const f of fishes) {
      const a = t * f.userData.speed + f.userData.phase;
      f.position.set(
        Math.cos(a) * f.userData.orbitR,
        f.userData.orbitY + Math.sin(t * 0.9 + f.userData.phase) * 0.6,
        Math.sin(a) * f.userData.orbitR
      );
      f.rotation.y = -a - Math.PI / 2;
    }
    // 黄绿鳗：缓速绕坑心巡游 + 身体起伏
    {
      const ea = t * 0.14 + eel.userData.phase;
      eel.position.set(Math.cos(ea) * 9, 17.5 + Math.sin(t * 0.7) * 1.1, Math.sin(ea) * 9);
      eel.rotation.y = -ea - Math.PI / 2;
      eel.rotation.z = Math.sin(t * 0.9) * 0.12;
    }
    // 粉色垂挂生物：绕悬点轻摆
    for (const h of hangers) {
      const ph = h.userData.phase || 0;
      h.rotation.z = Math.sin(t * 0.8 + ph) * 0.14;
      h.rotation.x = Math.cos(t * 0.6 + ph) * 0.1;
    }
    // 发光飞鸟：枝头间穿梭（径向往返）+ 拍翅
    for (const bird of birds) {
      const a = t * bird.userData.speed + bird.userData.phase;
      const rr = bird.userData.orbitR + Math.sin(t * 0.55 + bird.userData.phase * 2) * bird.userData.dart;
      bird.position.set(
        Math.cos(a) * rr,
        bird.userData.orbitY + Math.sin(t * 0.8 + bird.userData.phase) * 0.8,
        Math.sin(a) * rr
      );
      bird.rotation.y = -a; // 头朝行进切向
      const flap = Math.sin(t * 7 + bird.userData.phase) * 0.5;
      if (bird.userData.wingL) bird.userData.wingL.rotation.z = -0.5 - flap;
      if (bird.userData.wingR) bird.userData.wingR.rotation.z = 0.5 + flap;
    }
    // 长尾猴：坐望→跳枝；遇回扔果则侧跃躲避
    for (const mk of monkeys) {
      const u = mk.userData;
      const nPerch = u.perches.length;

      // ---- 躲避跳：回扔果逼近时强制弧线跃到更远枝头 ----
      if (u.dodgeT > 0) {
        u.dodgeT += _dt;
        const k = Math.min(1, u.dodgeT / 0.55);
        mk.position.lerpVectors(u.dodgeFrom, u.dodgeTo, k);
        mk.position.y += Math.sin(k * Math.PI) * (u.arc + 2.2);
        mk.lookAt(u.dodgeTo.x, mk.position.y, u.dodgeTo.z);
        // 躲避时前肢张开
        for (const arm of [u.armL, u.armR]) {
          if (arm) arm.rotation.x = arm.userData.baseRotX - 1.2;
        }
        if (k >= 1) {
          u.dodgeT = 0;
          // 对齐到最近 perch 索引，继续常规循环
          let bestI = 0;
          let bestD = Infinity;
          for (let i = 0; i < nPerch; i++) {
            const d = u.perches[i].distanceToSquared(u.dodgeTo);
            if (d < bestD) {
              bestD = d;
              bestI = i;
            }
          }
          u.idx = bestI;
          u.next = (bestI + 1 + ((Math.random() * (nPerch - 1)) | 0)) % nPerch;
          if (u.next === u.idx) u.next = (u.idx + 1) % nPerch;
          // 重置为「刚坐下」：避免落地立刻再投果
          const cyc = u.sitDur + u.jumpDur;
          const ciNow = Math.floor((t + u.phase) / cyc);
          u.phase = ciNow * cyc + 0.12 - t;
          u.lastCi = ciNow;
          u.throwCd = Math.max(u.throwCd || 0, 1.4);
        }
        continue;
      }

      const cyc = u.sitDur + u.jumpDur;
      const local = t + u.phase;
      const ci = Math.floor(local / cyc);
      if (ci !== u.lastCi) {
        u.lastCi = ci;
        u.idx = u.next;
        u.next = (u.next + 1) % nPerch;
      }
      const lt = local - ci * cyc;
      const A = u.perches[u.idx];
      const B = u.perches[u.next];
      if (lt < u.sitDur) {
        mk.position.copy(A);
        mk.position.y += Math.sin(t * 3.1 + u.phase) * 0.06;
        mk.lookAt(B.x, mk.position.y + 0.3, B.z);
      } else {
        const k = (lt - u.sitDur) / u.jumpDur;
        mk.position.lerpVectors(A, B, k);
        mk.position.y += Math.sin(k * Math.PI) * u.arc;
        mk.lookAt(B.x, mk.position.y, B.z);
      }

      // 侦测回扔果：逼近则躲避
      for (const fr of fruits) {
        const fu = fr.userData;
        if (!fu.active || fu.phase !== "return") continue;
        const dist = fr.position.distanceTo(mk.position);
        if (dist > FRUIT_DODGE_R) continue;
        _ffTmp.subVectors(mk.position, fr.position);
        // 果朝猴飞来（速度与相对位置同向）
        if (fu.vel.dot(_ffTmp) < 0.5) continue;
        // 挑一个离当前与来果方向都较远的枝头
        u.dodgeFrom.copy(mk.position);
        let best = u.perches[(u.idx + 1) % nPerch];
        let bestScore = -Infinity;
        for (const p of u.perches) {
          const awayFruit = p.distanceTo(fr.position);
          const awaySelf = p.distanceTo(mk.position);
          const score = awayFruit * 1.2 + awaySelf * 0.5 + Math.random();
          if (awaySelf > 2.5 && score > bestScore) {
            bestScore = score;
            best = p;
          }
        }
        u.dodgeTo.copy(best);
        u.dodgeT = 0.001;
        u.poseT = 0;
        break;
      }

      // 玩家入沼：冷却到了朝送信人投果
      u.throwCd = (u.throwCd || 0) - _dt;
      if (u.poseT > 0) {
        u.poseT -= _dt;
        if (player) mk.lookAt(_ffP.x, mk.position.y + 0.2, _ffP.z);
        const k = Math.sin(Math.min(1, 1 - u.poseT / 0.55) * Math.PI);
        for (const arm of [u.armL, u.armR]) {
          if (arm) arm.rotation.x = arm.userData.baseRotX - 2.4 * k;
        }
      } else {
        for (const arm of [u.armL, u.armR]) {
          if (arm) arm.rotation.x = arm.userData.baseRotX;
        }
        if (playerIn && u.throwCd <= 0 && lt < u.sitDur && u.dodgeT <= 0) {
          const fr = fruits.find((x) => !x.userData.active);
          if (fr) {
            u.throwCd = 1.8 + Math.random() * 2.6;
            u.poseT = 0.55;
            const fu = fr.userData;
            fu.active = true;
            fu.phase = "inbound";
            fu.owner = mk;
            fu.targetMk = null;
            fu.holdT = 0;
            fu.life = 5;
            fr.visible = true;
            fr.position.set(mk.position.x, mk.position.y + 1.2, mk.position.z);
            const T = 0.85 + Math.random() * 0.35;
            fu.vel.set(
              (_ffP.x - fr.position.x) / T,
              (_ffP.y + 1.0 - fr.position.y) / T + 0.5 * FRUIT_G * T,
              (_ffP.z - fr.position.z) / T
            );
          }
        }
      }
    }

    // 手中果：跟送信人；按 R / 点击 / 自动 0.35s 后回扔
    if (heldFruit && player) {
      const fu = heldFruit.userData;
      fu.holdT += _dt;
      heldFruit.position.set(_ffP.x + _ffF.x * 0.35, _ffP.y + 1.15, _ffP.z + _ffF.z * 0.35);
      const keys = runtime?.keys;
      // 接住约 0.35s 自动回扔，或按 R 立刻扔
      const wantThrow = fu.holdT >= 0.35 || !!keys?.KeyR;
      if (wantThrow) {
        // 瞄准：原投出的猴，否则最近猴
        let target = fu.owner;
        if (!target || !target.parent) {
          let bestD = Infinity;
          for (const mk of monkeys) {
            const d = mk.position.distanceToSquared(_ffP);
            if (d < bestD) {
              bestD = d;
              target = mk;
            }
          }
        }
        if (target) {
          fu.phase = "return";
          fu.targetMk = target;
          fu.life = 4;
          fu.holdT = 0;
          const aim = target.position;
          const T = 0.75 + Math.random() * 0.2;
          // 预判：朝猴当前位偏高一点，猴会躲开
          fu.vel.set(
            (aim.x - heldFruit.position.x) / T,
            (aim.y + 0.8 - heldFruit.position.y) / T + 0.5 * FRUIT_G * T,
            (aim.z - heldFruit.position.z) / T
          );
        } else {
          // 无目标：朝面朝方向抛出
          fu.phase = "return";
          fu.life = 3;
          fu.vel.set(_ffF.x * 8, 6, _ffF.z * 8);
        }
        heldFruit = null;
      }
    }

    // 果实弹道
    for (const fr of fruits) {
      const fu = fr.userData;
      if (!fu.active) continue;

      if (fu.phase === "held") {
        // 由 heldFruit 分支驱动位置
        continue;
      }

      // 袭击机队的果：轻追踪、无重力（主人 2026-09-05），命中 → 受击回调
      if (fu.phase === "raid") {
        fu.life -= _dt;
        let hit = false;
        if (fu.raidTargetObj?.parent) {
          fu.raidTargetObj.getWorldPosition(_raidV1);
          swampZone.worldToLocal(_raidV1);
          _raidV2.copy(_raidV1).sub(fr.position);
          const d = _raidV2.length();
          if (d < 2.2) hit = true;
          else {
            _raidV2.normalize().multiplyScalar(fu.vel.length() || 19);
            fu.vel.lerp(_raidV2, Math.min(1, _dt * 2.2));
          }
        }
        if (hit || fu.life <= 0) {
          if (hit && fu.raidOwner) onFleetHit?.(fu.raidOwner);
          fu.active = false;
          fr.visible = false;
          continue;
        }
        fr.position.addScaledVector(fu.vel, _dt);
        fr.rotation.x += _dt * 6;
        continue;
      }

      fu.life -= _dt;
      fu.vel.y -= FRUIT_G * _dt;
      fr.position.addScaledVector(fu.vel, _dt);
      fr.rotation.x += _dt * 6;
      fr.rotation.z += _dt * 4;

      // 入站果：送信人接住
      if (fu.phase === "inbound" && player && fr.position.distanceToSquared(_ffP) < FRUIT_CATCH_R2) {
        if (!heldFruit) {
          fu.phase = "held";
          fu.holdT = 0;
          fu.vel.set(0, 0, 0);
          fu.life = 6;
          heldFruit = fr;
        } else {
          // 已有果在手：弹开消失
          fu.active = false;
          fr.visible = false;
        }
        continue;
      }

      // 回扔：砸中猴（若未躲开）
      if (fu.phase === "return") {
        for (const mk of monkeys) {
          if (fr.position.distanceToSquared(mk.position) < FRUIT_HIT_MONKEY_R2) {
            // 命中：吓一跳，强制短躲避
            const u = mk.userData;
            if (u.dodgeT <= 0) {
              u.dodgeFrom.copy(mk.position);
              u.dodgeTo.copy(u.perches[(u.idx + 1 + ((Math.random() * 2) | 0)) % u.perches.length]);
              u.dodgeT = 0.001;
            }
            fu.active = false;
            fr.visible = false;
            break;
          }
        }
      }

      if (!fu.active) continue;
      if (fu.life <= 0 || fr.position.y < WATER_Y + 0.15) {
        if (heldFruit === fr) heldFruit = null;
        fu.active = false;
        fr.visible = false;
        fu.owner = null;
        fu.targetMk = null;
      }
    }
    // 发光蜥蜴：贴地缓爬，头朝行进向微摆
    updateGroundLizards(t);
    // 发光带鱼：环游 + 带状身体波动摆尾
    for (const rf of ribbons) {
      const u = rf.userData;
      const a = t * u.speed + u.phase;
      rf.position.set(
        Math.cos(a) * u.orbitR,
        u.orbitY + Math.sin(t * 0.8 + u.phase) * 0.5,
        Math.sin(a) * u.orbitR
      );
      rf.rotation.y = -a - Math.PI / 2; // 头(+X)朝行进向
      const rp = u.bodyMesh.geometry.attributes.position;
      for (let i = 0; i < rp.count; i++) {
        const x = u.baseX[i];
        const tailK = 0.5 - x / 3.8; // 头 0 → 尾 1
        rp.setZ(i, (u.baseZ?.[i]||0)+Math.sin(x * 2.0 - t * u.wave + u.phase) * 0.3 * (0.15 + 0.85 * tailK));
      }
      rp.needsUpdate = true;
    }
    // 水下泅游的孩子：绕鲸缓游 + 打腿摆
    {
      const a = t * 0.1 + 2.4;
      swimmer.position.set(7 + Math.cos(a) * 6.5, 20.6 + Math.sin(t * 0.9) * 0.4, 4 + Math.sin(a) * 6.5);
      swimmer.rotation.y = -a;
      swimmer.rotation.z = Math.sin(t * 2.6) * 0.18;
      for(const limb of swimmer.userData.coralSwimLimbs||[]){
        limb.node.rotation.x=Math.sin(t*(limb.arm?1.6:2.6)+limb.side*Math.PI*.5)*(limb.arm?.24:.31);
        limb.node.rotation.z=limb.arm?Math.sin(t*1.6+limb.side*Math.PI*.5)*.12:0;
      }
    }
    // 食物碎屑微光闪烁
    for (const b of foodBits) {
      setCoralGlowOpacity(b, 0.45 + 0.45 * (0.5 + 0.5 * Math.sin(t * 3 + b.userData.phase)));
    }
    // 赛博水墨虎巡游/饮水；传入 player 以便见送信人跳下相见
    tiger.userData.update?.(_dt, t, runtime);

    /* ---------- 战船维修厂动画：猴吊桅杆 / 蜥蜴送水 / 船B 出沼 + 白鲸护送 ---------- */
    {
      // 正式页已确认整座船坞完全在全球海壳下：不再更新不可见的桨、尾流
      // 和船员动画，避免即使已从场景树摘除仍留下的 CPU 消耗。
      if (shipA.userData.officialOceanOccluded || shipB.userData.officialOceanOccluded) {
        // 这两艘船共用同一船坞剧情；只要正式页剔除了其中任意一艘，整段
        // 船坞表演都不可能露出水面。
      } else {
      const dt = Math.min(0.05, Math.max(0.001, Number(_dt) || 1 / 60));
      // 船A 泊稳微浮（随水呼吸），桨兵静坐待命
      shipA.position.y = WATER_Y + 0.02 + Math.sin(t * 0.9) * 0.05;
      shipA.rotation.z = Math.sin(t * 0.7) * 0.012;
      updateWarshipOars(shipA, dt, 0);
      for (const spar of spars) {
        spar.position.y = WATER_Y + 0.05 + Math.sin(t * 0.85 + spar.userData.bobPhase) * 0.06;
      }

      // -- 长尾猴换桅杆循环：静候(2.5s) → 吊起(4s) → 就位(5.5s) → 放下(4s)
      const cyc = (t + 1.5) % 16;
      let liftK = 0; // 0 = 平躺待吊 → 1 = 竖直就位
      if (cyc < 2.5) liftK = 0;
      else if (cyc < 6.5) liftK = (cyc - 2.5) / 4;
      else if (cyc < 12) liftK = 1;
      else liftK = 1 - (cyc - 12) / 4;
      liftK = liftK * liftK * (3 - 2 * liftK);
      mastPivot.rotation.z = Math.PI / 2 * (1 - liftK) + Math.sin(t * 2.2) * 0.02 * liftK;
      mastPivot.position.z = 0.3 * (1 - liftK);
      // 甲板推举猴：随吊起进度举臂发力（手臂高举 + 微颤）
      const lifting = liftK > 0.02 && liftK < 0.98;
      const armBase = mkLift.userData.armL.userData.baseRotX ?? -0.3;
      mkLift.userData.armL.rotation.x = armBase - 1.55 * liftK + (lifting ? Math.sin(t * 9.5) * 0.06 : 0);
      mkLift.userData.armR.rotation.x = armBase - 1.65 * liftK + (lifting ? Math.sin(t * 9.5 + 1.2) * 0.06 : 0);
      mkLift.rotation.x = -0.18 * liftK;
      // 桅顶工猴：反向自旋保持直立；就位后在桅顶挥手
      mkTop.rotation.z = -mastPivot.rotation.z;
      const topArmBase = mkTop.userData.armR.userData.baseRotX ?? -0.3;
      mkTop.userData.armR.rotation.x =
        liftK > 0.96 ? topArmBase - 1.2 + Math.sin(t * 3.1) * 0.5 : topArmBase - 0.9 * liftK;
      swampZone.userData.flowerBoyActivities?.repair?.update(t,liftK);

      // -- 送水蜥蜴：沿甲板右舷走道往返，水珠逐个弧抛到两列纸兵头顶
      const lzX = Math.sin(t * 0.32) * 1.25;
      const lzDir = Math.cos(t * 0.32) >= 0 ? 1 : -1;
      waterLizard.position.set(lzX, 0.66, 0.28);
      waterLizard.rotation.y = lzDir > 0 ? Math.PI / 2 : -Math.PI / 2;
      waterLizard.rotation.z = Math.sin(t * 6.2) * 0.07;
      const crewRows = shipA.userData.crew?.userData?.rows || [];
      for (const drop of waterDrops) {
        const seed = drop.userData.seed;
        const ph = (t * 0.55 + seed * 0.48) % 2.4; // 每 2.4s 抛一珠，5 珠错相
        if (ph < 0.85 && crewRows.length) {
          // Keep one recipient throughout a throw; V6 rows expose an attachment, not row.x.
          if (!drop.visible || drop.userData.deliveryRowIndex == null) {
            drop.userData.deliveryRowIndex = (seed + Math.floor(t * 0.6)) % crewRows.length;
          }
          const row = crewRows[drop.userData.deliveryRowIndex % crewRows.length];
          const target = drop.userData.deliveryTarget;
          if (row.attach) {
            row.attach.getWorldPosition(target);
            shipA.worldToLocal(target);
            target.y += 0.33;
          } else if (Number.isFinite(row.x) && Number.isFinite(row.side)) {
            target.set(row.x, 1.32, row.side * 0.28);
          } else { drop.visible = false; continue; }
          if (!Number.isFinite(target.x + target.y + target.z)) { drop.visible = false; continue; }
          const k = ph / 0.85;
          drop.visible = true;
          drop.position.set(
            lzX + (target.x - lzX) * k,
            1.12 + (target.y - 1.12) * k + Math.sin(k * Math.PI) * 0.42,
            0.28 + (target.z - 0.28) * k
          );
          setCoralGlowOpacity(drop, 0.2 + 0.75 * Math.sin(k * Math.PI));
        } else {
          drop.visible = false;
        }
      }

      // -- 船B：泊稳(9s) → 全桨驶向入口豁口(11s) → 爬阶出沼渐隐(6s)
      const DUR_ALL=26,bt=(t+4)%DUR_ALL;
      const bPhase=bt<9?'dock':'sail';
      const k=bPhase==='dock'?0:(bt-9)/17,phase=k*k*(3-2*k)*Math.PI*2;
      const stroke=shipB.userData.oarPhase/6.2*Math.PI*2;
      const angle=phase+.014*(1-Math.cos(stroke))*Math.sin(Math.PI*k)**2;
      shipB.position.set(9+1.5*Math.cos(angle),WATER_Y+.02+Math.sin(t*1.3)*.04,8+2.5*Math.sin(angle));
      const dx=-1.5*Math.sin(angle),dz=2.5*Math.cos(angle);
      shipB.rotation.y=Math.atan2(-dz,dx);shipB.scale.setScalar(SHIPB_SCALE);shipB.visible=true;
      updateWarshipOars(shipB,dt,bPhase==='dock'?0:Math.hypot(dx,dz)*6*k*(1-k)*Math.PI*2/17/2.3);
      shipB.userData.swampLakeVoyage.phase=bPhase;shipB.userData.swampLakeVoyage.cycle=bt;

      // -- 护送白鲸：泊位绕游 → 左舷并游 → 出口破水领航，随后潜回泊位
      const bDirX = Math.cos(shipB.rotation.y);
      const bDirZ = -Math.sin(shipB.rotation.y);
      escortWhale.visible=true;
      const escortK=THREE.MathUtils.smoothstep(k,0,.1)*(1-THREE.MathUtils.smoothstep(k,.9,1));
      const side=5.7,lead=.35+.4*Math.sin(t*.4)*(1-escortK);
      escortWhale.position.set(shipB.position.x-Math.sin(shipB.rotation.y)*side+bDirX*lead,WATER_Y-.7+Math.sin(t*1.1)*.18,shipB.position.z-Math.cos(shipB.rotation.y)*side+bDirZ*lead);
      escortWhale.rotation.y=Math.atan2(bDirX,bDirZ);escortWhale.rotation.x=-.12+Math.sin(t*.9)*.06;

      }
    }
    // 气泡
    for (const b of bubbles) {
      b.position.y = b.userData.baseY + Math.sin(t * 1.5 + b.userData.phase) * 0.5;
      b.material.opacity = 0.22 + 0.22 * (0.5 + 0.5 * Math.sin(t * 2.1 + b.userData.phase));
    }
    // 萤火虫：玩家入沼 → 大部分环绕/尾随送信人，离开后平滑回归环境漂移
    for (const f of fireflies) {
      const u = f.userData;
      const tt = t * u.speed + u.phase;
      const ax = u.baseX + Math.sin(tt * 0.9) * u.range + Math.sin(tt * 0.37 + 1.7) * u.range * 0.6;
      const ay = u.baseY + Math.sin(tt * 0.7 + u.phase) * 1.2;
      const az = u.baseZ + Math.cos(tt * 0.8) * u.range;
      u.followK += ((playerIn ? 1 : 0) - u.followK) * Math.min(1, _dt * 1.5);
      if (u.followK > 0.002 && player) {
        let tx, ty, tz;
        if (u.trail) {
          // 尾随：身后 1~3 单位拖尾
          const back = 1.8 + Math.sin(tt * 0.7 + u.orbitPh) * 0.8;
          tx = _ffP.x - _ffF.x * back + Math.sin(tt * 1.3 + u.orbitPh) * 0.6;
          ty = _ffP.y + 1.2 + Math.sin(tt * 0.9 + u.orbitPh) * 0.5;
          tz = _ffP.z - _ffF.z * back + Math.cos(tt * 1.1 + u.orbitPh) * 0.6;
        } else {
          // 环绕：绕玩家水平圆周 + 头顶浮动
          const oa = t * u.orbitSpd + u.orbitPh;
          tx = _ffP.x + Math.cos(oa) * u.orbitR;
          ty = _ffP.y + u.orbitH + Math.sin(t * 1.3 + u.orbitPh) * 0.45;
          tz = _ffP.z + Math.sin(oa) * u.orbitR;
        }
        const k = u.followK;
        f.position.set(ax + (tx - ax) * k, ay + (ty - ay) * k, az + (tz - az) * k);
      } else {
        f.position.set(ax, ay, az);
      }
      const tw = 0.5 + 0.5 * Math.sin(t * u.flicker + u.phase * 3);
      setCoralGlowOpacity(f, u.op * (0.3 + 0.7 * tw));
    }
    // 花蕊光晕呼吸
    for (const h of glowHalos) {
      setCoralGlowOpacity(h, 0.38 + 0.26 * (0.5 + 0.5 * Math.sin(t * 1.6 + (h.userData.pulse || 0))));
    }
    // 光池微闪
    for (const p of pools) {
      setCoralGlowOpacity(p, 0.05 + 0.04 * (0.5 + 0.5 * Math.sin(t * 0.7 + p.userData.phase)));
    }
    // 月光柱微弱呼吸
    shaftMat.opacity = shaftOpacityFactor * (0.022 + 0.012 * (0.5 + 0.5 * Math.sin(t * 0.4)));
    // 水面微漾（玻璃顶点轻晃）
    const p = water.geometry.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), z = p.getZ(i);
      p.setY(i, Math.sin(t * 1.2 + x * 0.22 + z * 0.18) * 0.14);
    }
    p.needsUpdate = true;
  };

  swampZone.userData.coralAtmosphere = {enabled: coralAtmosphereEnabled(), haloSizeFactor: .35, haloOpacityFactor: .2, stamenSizeFactor: .45, stamenOpacityFactor: .35, shaftOpacityFactor};
  applySwampV2Art(swampZone);
  rootedAlgae.refreshAttachment(); // V2 replaces the bed geometry; sample that actual final surface.
  installFlowerBoyActivities(swampZone,lotuses,whale,foodBits,{whales,shipyard:swampZone.userData.shipyard});
  if (coralLizardRoutesEnabled && swampZone.userData.gregCoralRim?.ok) updateGroundLizards(0);
  return swampZone;
}

/* =====================================================================
 *  放置工厂与球面贴放（保持对外导出接口不变）
 * ===================================================================== */

/**
 * 球面贴合修正：星球是弯曲的，坑缘平坦切平面之外地表会下沉。
 * 大树 / 草皮按放置缩放下的真实球半径沿球面下探，树朝法线倾斜生长，
 * 避免悬浮。幂等：可重复调用（缩放变更时重新贴合）。
 *
 * @param {THREE.Group} swampZone createMoebiusSwampZone 的返回组
 * @param {number} scale 放置时的包装缩放
 * @param {number} [surfaceR] 坑口地表处的星球径向半径（R + 地表抬升），
 *                            局部有效球半径 = surfaceR / scale
 */
export function applySwampSphereFit(swampZone, scale, surfaceR = PLANET_RADIUS) {
  const Rs = surfaceR / Math.max(1e-4, scale); // 局部坐标下的有效球半径
  const drop = (d) => (d >= Rs ? 0 : Rs - Math.sqrt(Rs * Rs - d * d));
  const trees = swampZone.userData.towerTrees || [];
  for (const tree of trees) {
    const d = Math.hypot(tree.position.x, tree.position.z);
    // 多埋 0.8 局部单位：树干底部扎进土里，兼补生成/放置地表半径的小偏差
    tree.position.y = SWAMP_LOCAL_GROUND_Y - 0.3 - drop(d) - 0.8;
    // 局部 +Y 对齐该点球面法线（树朝外倾斜，根部埋土）再绕法线自转
    _swT.set(tree.position.x, Rs - drop(d), tree.position.z).normalize();
    tree.quaternion.copy(quatYToDir(_swT, _swQ));
    tree.rotateY(tree.userData.yaw ?? 0);
  }
  const decor = swampZone.userData.rimDecor || [];
  for (const m of decor) {
    const d = Math.hypot(m.position.x, m.position.z);
    m.position.y = (m.userData.baseY ?? SWAMP_LOCAL_GROUND_Y) - drop(d);
  }
  return swampZone;
}

/**
 * 地图 / 目录用工厂：包装原点 = 正常地表（局部 Y=40）。
 * 放置后玩家脚下即坑口草地，坑内向球心塌陷 30 单位直达湖底。
 *
 * @param {{ seed?: number, scale?: number }} [opts]
 * @returns {THREE.Group}
 */
export function createMoebiusSwampPlacement(opts = {}) {
  const scale = opts.scale ?? 0.5;
  const seed = opts.seed ?? 7711;
  const inner = createMoebiusSwampZone({ seed, tigerAnatomy: opts.tigerAnatomy });
  // 将局部 Y=40 的地表对齐包装原点：inner.y = -40
  inner.position.y = -SWAMP_LOCAL_GROUND_Y;

  const wrap = new THREE.Group();
  wrap.name = "moebius-swamp-placement";
  wrap.add(inner);
  wrap.scale.setScalar(scale);
  applySwampSphereFit(inner, scale);

  wrap.userData.kind = "moebius-swamp";
  wrap.userData.assetType = "moebiusSwamp";
  wrap.userData.displayName = "莫比斯湖沼";
  wrap.userData.collideRadius = 0; // 可走入资产：不注册碰撞墙
  wrap.userData.factoryScale = scale;
  wrap.userData.seed = seed;
  wrap.userData.inner = inner;
  wrap.userData.nectarTargets = []; // 由 inner.update 同步：水面落花蜜源（世界坐标）
  wrap.userData.update = (dt, t, runtime) => {
    inner.update?.(dt, t, runtime);
    // 镜像蜜源列表，方便外部只拿 wrap（地图放置根）
    wrap.userData.nectarTargets = inner.userData.nectarTargets || [];
  };

  return wrap;
}

/**
 * 书店平面坐标与水晶城（峡谷谷心）之间的中点球面方向
 */
export function swampMidwayDir(bookshopX, bookshopZ, R = PLANET_RADIUS) {
  const { lat, lon } = flatXZToLatLon(bookshopX, bookshopZ, R);
  const bookDir = latLonToDir(lat, lon, new THREE.Vector3());
  const cityDir = latLonToDir(CANYON.lat, CANYON.lon, new THREE.Vector3());
  const mid = bookDir.clone().add(cityDir);
  if (mid.lengthSq() < 1e-8) return cityDir.clone();
  return mid.normalize();
}

const _swP = new THREE.Vector3();
const _swT = new THREE.Vector3();
const _swUp = new THREE.Vector3();
const _swRight = new THREE.Vector3();
const _swM = new THREE.Matrix4();
const _swQ = new THREE.Quaternion();
const _swBook = new THREE.Vector3();
const _swCity = new THREE.Vector3();
const _swMid = new THREE.Vector3();
const _swTarget = new THREE.Vector3();

/**
 * 把湖沼锚到电车轨道附近（坑口地表 Y=40 对齐目标点，非浮空盘子）
 * 位置：书店→原中点 的 25% 距离。
 */
export function placeMoebiusSwampOnTrack(
  swampZone,
  trackCurve,
  bookshopX,
  bookshopZ,
  R = PLANET_RADIUS,
  scale = 0.5
) {
  if (!trackCurve) {
    const { lat, lon } = flatXZToLatLon(bookshopX, bookshopZ, R);
    latLonToDir(lat, lon, _swBook);
    latLonToDir(CANYON.lat, CANYON.lon, _swCity);
    _swMid.copy(_swBook).add(_swCity).normalize();
    _swTarget.copy(_swBook).lerp(_swMid, 0.25).normalize();
    return placeMoebiusSwampOnSphere(swampZone, _swTarget, R, scale, 0);
  }

  const { lat, lon } = flatXZToLatLon(bookshopX, bookshopZ, R);
  latLonToDir(lat, lon, _swBook);
  latLonToDir(CANYON.lat, CANYON.lon, _swCity);

  let midT = 0.35;
  let midScore = Infinity;
  const N = 360;
  for (let i = 0; i < N; i++) {
    const t = i / N;
    trackCurve.getPointAt(t, _swP);
    _swUp.copy(_swP).normalize();
    const ab = _swBook.angleTo(_swUp);
    const bc = _swUp.angleTo(_swCity);
    const score =
      Math.abs(ab - bc) * 2.2 + (bc < 0.12 ? 2.5 : 0) + (ab < 0.08 ? 1.5 : 0);
    if (score < midScore) {
      midScore = score;
      midT = t;
    }
  }
  trackCurve.getPointAt(midT, _swP);
  _swMid.copy(_swP).normalize();
  _swTarget.copy(_swBook).lerp(_swMid, 0.25).normalize();

  let bestT = midT;
  let bestDot = -Infinity;
  for (let i = 0; i < N; i++) {
    const t = i / N;
    trackCurve.getPointAt(t, _swP);
    _swUp.copy(_swP).normalize();
    const d = _swUp.dot(_swTarget);
    const ab = _swBook.angleTo(_swUp);
    const score = d - (ab < 0.05 ? 0.15 : 0);
    if (score > bestDot) {
      bestDot = score;
      bestT = t;
    }
  }

  trackCurve.getPointAt(bestT, _swP);
  trackCurve.getTangentAt(bestT, _swT);
  _swUp.copy(_swP).normalize();
  _swT.addScaledVector(_swUp, -_swT.dot(_swUp));
  if (_swT.lengthSq() < 1e-8) {
    _swT.set(0, 0, 1).addScaledVector(_swUp, -_swUp.z);
  }
  _swT.normalize();
  _swRight.crossVectors(_swT, _swUp).normalize();
  _swM.makeBasis(_swT, _swUp, _swRight);
  _swQ.setFromRotationMatrix(_swM);

  swampZone.scale.setScalar(scale);
  swampZone.quaternion.copy(_swQ);
  applySwampSphereFit(swampZone, scale, _swP.length());

  // 坑口地表（包装原点）对齐轨旁地表点 → 玩家可行走进入坑缘
  // （inner 已内移 -40，坑缘即在包装原点，无需再减 40×scale）
  swampZone.position.copy(_swP);

  swampZone.userData.trackParam = bestT;
  swampZone.userData.onTrack = true;
  swampZone.userData.bookshopDistanceFactor = 0.25;
  return swampZone;
}

/**
 * 球面贴放：坑口草地精确贴齐星球地表，整个湖沼向球心方向深挖塌陷，
 * 玩家从草地边缘一跃而下。
 * （inner 已内移 -40：坑缘 = 包装原点，故直接定位到 R + surfaceLift，
 * 切勿再减 SWAMP_LOCAL_GROUND_Y×scale，否则会双重下移埋入地下。）
 */
export function placeMoebiusSwampOnSphere(
  swampZone,
  dir,
  R = PLANET_RADIUS,
  scale = 0.5,
  surfaceLift = 0
) {
  swampZone.scale.setScalar(scale);
  swampZone.quaternion.copy(quatYToDir(dir, new THREE.Quaternion()));
  swampZone.rotateY(0.5);
  applySwampSphereFit(swampZone, scale, R + surfaceLift);
  // 坑缘（包装原点）对齐 R + surfaceLift
  const surface = dir.clone().multiplyScalar(R + surfaceLift);
  swampZone.position.copy(surface);
  return swampZone;
}

// =====================================================================
//  独立工厂：绿黑斑纹小鱼群 / 萤火虫群
//  从 createMoebiusSwampZone 内部逻辑提取，收拢为紧凑可放置组件。
//  不改动 zone 原有 inline 生成逻辑（zone 内仍用大范围散布）。
// =====================================================================

// Both the formal lake and the component preview use this anatomy. Random
// spots deliberately consume the original 2/3 samples before placement draws.
function buildCoralSmallFish(rnd,index){
  const fish=new THREE.Group();fish.name=`swamp-fish-${index}`;
  const skin=index%2?0x91b4a0:0x779f97,fin=0xbdc9b0;
  const pieces=[coralEllipsoid([0,0,.05],[.23,.235,.64],skin),
    coralEllipsoid([0,-.095,.15],[.18,.14,.49],0xcbd4b8),
    coralEllipsoid([0,0,-.69],[.085,.075,.21],skin),
    coralEllipsoid([0,.10,-.91],[.026,.20,.16],fin,[.34,0,0]),
    coralEllipsoid([0,-.10,-.91],[.026,.20,.16],fin,[-.34,0,0]),
    coralEllipsoid([0,.21,-.12],[.022,.12,.25],fin)];
  for(const side of [-1,1]){
    pieces.push(coralEllipsoid([side*.20,-.065,.10],[.15,.023,.16],fin,[0,side*.35,side*.18]));
    pieces.push(coralEllipsoid([side*.14,.06,.51],[.014,.024,.026],0x435968));
  }
  for(let k=0;k<2+(index%2);k++){
    const z=(rnd()-.5)*.5;
    pieces.push(coralEllipsoid([(k%2?1:-1)*.219,.07,z],[.011,.041,.054],0x52766d));
  }
  const mesh=coralFineActorBatch(pieces);mesh.name='swamp-small-fish-anatomy';fish.add(mesh);
  fish.userData.coralFaunaVersion=1;return fish;
}
let coralFireflyTexture;
function buildCoralFirefly(color,size){
  const sp=glowSprite(color,size,.8);
  if(coralAtmosphereEnabled()){
    if(!coralFireflyTexture){
      const size=32,data=new Uint8Array(size*size*4);
      for(let y=0;y<size;y++)for(let x=0;x<size;x++){
        const r=Math.hypot((x+.5)/size-.5,(y+.5)/size-.5),i=(y*size+x)*4;
        data[i]=data[i+1]=data[i+2]=255;
        data[i+3]=Math.round(255*(r<.15?1:r<.23?(.23-r)/.08:0));
      }
      coralFireflyTexture=new THREE.DataTexture(data,size,size);coralFireflyTexture.needsUpdate=true;
      coralFireflyTexture.minFilter=coralFireflyTexture.magFilter=THREE.LinearFilter;
    }
    // The core is spatially tiny; the broad-halo opacity factor made it vanish.
    // Keep its original point size/phase, but retain visible local radiance.
    sp.userData.coralGlow.opacityFactor=.75;
    setCoralGlowOpacity(sp,.8);
    sp.material.map=coralFireflyTexture;sp.material.needsUpdate=true;
    sp.userData.coralFaunaVersion=1;
  }
  return sp;
}

/** 绿黑斑纹小鱼群（9条，圆形排布，可独立放置） */
function buildFishSchool(rnd = Math.random) {
  const g = new THREE.Group();
  g.name = "swamp-fish-school";
  for (let i = 0; i < 9; i++) {
    const fish = buildCoralSmallFish(rnd, i);
    // 独立放置：紧凑圆形排布（zone 内用 ±15 大范围，这里收拢到半径 ~1.5）
    const a = (i / 9) * Math.PI * 2;
    const d = 1.0 + (rnd() - 0.5) * 0.6;
    fish.position.set(Math.cos(a) * d, (rnd() - 0.5) * 1.2, Math.sin(a) * d);
    fish.userData.orbitR = d;
    fish.userData.orbitY = fish.position.y;
    fish.userData.phase = rnd() * Math.PI * 2;
    fish.userData.speed = 0.25 + rnd() * 0.3;
    g.add(fish);
  }
  return g;
}

/** 萤火虫群（46点辉光，球形散布，可独立放置） */
function buildFireflies(rnd = Math.random) {
  const g = new THREE.Group();
  g.name = "swamp-fireflies";
  for (let i = 0; i < 46; i++) {
    const sp = buildCoralFirefly(i % 3 === 2 ? FIREFLY_B : FIREFLY_A, 0.5 + rnd() * 0.7);
    const a = rnd() * Math.PI * 2;
    const d = rnd() * 5;
    const y = rnd() * 6;
    sp.position.set(Math.cos(a) * d, y, Math.sin(a) * d);
    sp.userData.baseX = sp.position.x;
    sp.userData.baseY = sp.position.y;
    sp.userData.baseZ = sp.position.z;
    sp.userData.range = 1.5 + rnd() * 2.5;
    sp.userData.speed = 0.25 + rnd() * 0.4;
    sp.userData.flicker = 2 + rnd() * 3;
    sp.userData.phase = rnd() * Math.PI * 2;
    sp.userData.op = 0.5 + rnd() * 0.5;
    sp.userData.followK = 0;
    sp.userData.orbitR = 1.4 + rnd() * 2.4;
    sp.userData.orbitH = 0.6 + rnd() * 2.2;
    sp.userData.orbitSpd = (0.8 + rnd() * 1.4) * (rnd() < 0.5 ? -1 : 1);
    sp.userData.orbitPh = rnd() * Math.PI * 2;
    sp.userData.trail = i % 3 === 0;
    g.add(sp);
  }
  return g;
}

// =====================================================================
//  生态组件集中导出（不影响上面任何逻辑）：供截图 harness / 地图编辑器
//  单独实例化。仅新增导出，未改动任何现有函数的实现。
// =====================================================================
export const SWAMP_COMPONENT_BUILDERS = {
  whale: buildBelugaWhale,
  worldTree: buildWorldTree,
  nativeDoll: buildNativeDoll,
  lotusLeafBoat: createLotusLeafBoat,
  swampEel: buildSwampEel,
  tubeWormCluster: buildTubeWormCluster,
  moebiusMushroom: buildMoebiusMushroom,
  pinkHanger: buildPinkHanger,
  swampBird: buildSwampBird,
  longTailMonkey: buildLongTailMonkey,
  glowLizard: buildGlowLizard,
  ribbonFish: buildRibbonFish,
  shell: buildShell,
  rimPalm: buildRimPalm,
  toweringTree: buildToweringTree,
  canopyCeiling: buildCanopyCeiling,
  glowFlower: buildGlowFlower,
  giantFlower: buildGiantFlower,
  stamenSpike: buildStamenSpike,
  fishSchool: buildFishSchool,
  fireflies: buildFireflies,
};
